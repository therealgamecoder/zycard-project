# 🚀 INSTRUÇÕES DE ATUALIZAÇÃO - Localização e Storage

## 🔥 **COMO RESOLVER O ERRO DE STORAGE (URGENTE):**

### 1. **Criar Buckets no Supabase** ⚡
1. Acesse o **painel do Supabase**
2. Vá em **Storage** (menu lateral)
3. Clique em **"Create Bucket"**
4. Crie os 2 buckets:

**Bucket 1:**
- Name: `backgrounds`
- Public: ✅ **SIM** (marcar como público)

**Bucket 2:**
- Name: `avatars`
- Public: ✅ **SIM** (marcar como público)

---

## 📊 **BANCO DE DADOS - Execute na ordem:**

### 1. **SQL Principal - Nova Funcionalidade de Localização:**
Execute o arquivo `database-new-features.sql` completo no **SQL Editor** do Supabase.

**OU execute manualmente:**

```sql
-- Adicionar campo de país
ALTER TABLE public.visual_cards 
ADD COLUMN country TEXT;

-- Criar índice para performance
CREATE INDEX IF NOT EXISTS idx_visual_cards_country ON public.visual_cards(country);
```

### 2. **Tabela de Países (Opcional - mas recomendado):**
```sql
-- Criar tabela de países
CREATE TABLE IF NOT EXISTS public.countries (
    code TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    name_pt TEXT NOT NULL,
    flag_emoji TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Enable RLS
ALTER TABLE public.countries ENABLE ROW LEVEL SECURITY;

-- Política de leitura pública
CREATE POLICY "Countries are publicly readable" ON public.countries
    FOR SELECT USING (true);

-- Permissions
GRANT SELECT ON public.countries TO anon, authenticated;
```

### 3. **Inserir Dados dos Países:**
Execute a parte dos `INSERT INTO public.countries` do arquivo `database-new-features.sql` (são muitos países pré-configurados).

---

## 🗂️ **POLÍTICAS DE STORAGE (Configurar após criar buckets):**

### Para o bucket `avatars`:
```sql
-- Upload
CREATE POLICY "Users can upload avatars" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'avatars' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Visualização pública
CREATE POLICY "Avatar images are publicly accessible" ON storage.objects
FOR SELECT USING (bucket_id = 'avatars');

-- Update
CREATE POLICY "Users can update own avatars" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'avatars' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Delete
CREATE POLICY "Users can delete own avatars" ON storage.objects
FOR DELETE USING (
  bucket_id = 'avatars' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);
```

### Para o bucket `backgrounds`:
```sql
-- Upload
CREATE POLICY "Users can upload backgrounds" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'backgrounds' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Visualização pública
CREATE POLICY "Background images are publicly accessible" ON storage.objects
FOR SELECT USING (bucket_id = 'backgrounds');

-- Update
CREATE POLICY "Users can update own backgrounds" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'backgrounds' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Delete
CREATE POLICY "Users can delete own backgrounds" ON storage.objects
FOR DELETE USING (
  bucket_id = 'backgrounds' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);
```

---

## ✅ **VERIFICAR SE FUNCIONOU:**

### 1. **Teste de Storage:**
- Dashboard → Editar card → Fazer upload de foto
- Se não der erro "Bucket not found" = ✅ funcionou

### 2. **Teste de Localização:**
- Dashboard → Editar card → Selecionar país
- Salvar e verificar se aparece o país com bandeira no card = ✅ funcionou

### 3. **Funcionalidades Implementadas:**
- ✅ Modal de edição (não redireciona mais)
- ✅ Upload de foto de fundo e perfil
- ✅ Seleção de país/localização
- ✅ Visualização da localização nos cards
- ✅ Seção "Funcionalidades em desenvolvimento"

---

## 🎯 **RESUMO DAS NOVIDADES:**

### **Para o usuário:**
1. **Localização**: Pode selecionar país no perfil
2. **Fotos**: Upload de foto de fundo e perfil
3. **Modal**: Edição sem sair da página
4. **Preview**: Ver funcionalidades que vão chegar

### **Para o desenvolvedor:**
1. Novo hook: `useCountries()`
2. Novos componentes: `EditCardModal`, `DevelopmentFeatures`
3. Banco atualizado com: `country` field + tabela `countries`
4. Storage configurado: buckets `avatars` e `backgrounds`

---

## 🔧 **SE ALGO DER ERRADO:**

### **"Bucket not found":**
- Certifique-se que criou os buckets `avatars` e `backgrounds`
- Marque como públicos
- Configure as políticas de storage

### **"Country field missing":**
- Execute: `ALTER TABLE public.visual_cards ADD COLUMN country TEXT;`

### **Dropdown de países vazio:**
- Execute os `INSERT INTO public.countries` do arquivo SQL
- Verifique se a política de leitura está ativa

**TUDO PRONTO! 🚀**