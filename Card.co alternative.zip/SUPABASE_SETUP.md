# Configuração do Supabase - Guia Completo

Este guia explica como configurar completamente o Supabase para o projeto VisualCard.

## 🚀 Passo 1: Criar Projeto no Supabase

1. Acesse [https://supabase.com](https://supabase.com)
2. Clique em "Start your project"
3. Faça login ou crie uma conta
4. Clique em "New Project"
5. Preencha:
   - **Name**: VisualCard (ou nome de sua escolha)
   - **Database Password**: Uma senha segura (anote!)
   - **Region**: Escolha a região mais próxima
6. Clique em "Create new project"
7. Aguarde alguns minutos para o projeto ser criado

## 🗄️ Passo 2: Configurar o Banco de Dados

### 2.1 Acessar o SQL Editor
1. No painel do Supabase, clique em **SQL Editor** na barra lateral
2. Clique em **New Query**

### 2.2 Executar Script de Configuração
1. Abra o arquivo `database-setup.sql` deste projeto
2. Copie TODO o conteúdo do arquivo
3. Cole no SQL Editor do Supabase
4. Clique em **RUN** (ou pressione Ctrl/Cmd + Enter)
5. Aguarde a execução completa (pode levar alguns segundos)

### 2.3 Verificar Instalação
Após executar o script, você deve ver:
- ✅ Várias mensagens de sucesso
- ✅ Tabelas criadas: profiles, visual_cards, social_links, etc.
- ✅ Políticas RLS criadas
- ✅ Triggers e funções criadas

## 🔑 Passo 3: Obter Credenciais

### 3.1 Encontrar as Credenciais
1. No painel do Supabase, clique em **Settings** (engrenagem na barra lateral)
2. Clique em **API**
3. Você verá duas informações importantes:

   **Project URL**
   ```
   https://xxxxxxxxxxxxx.supabase.co
   ```

   **Project API Keys** → **anon public**
   ```
   eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   ```

### 3.2 Configurar Variáveis de Ambiente
1. No projeto, crie o arquivo `.env.local`
2. Adicione as credenciais:

```env
VITE_SUPABASE_URL=https://SEU_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=SUA_ANON_KEY_AQUI
```

**⚠️ IMPORTANTE**: 
- Substitua `SEU_PROJECT_ID` e `SUA_ANON_KEY_AQUI` pelos valores reais
- NUNCA commite este arquivo no git
- Use apenas a **anon public** key, NÃO a service_role

## 📧 Passo 4: Configurar Autenticação

### 4.1 Configurar Provedores de Auth
1. Vá em **Authentication** → **Providers**
2. **Email**: Certifique-se que está habilitado
3. **Confirm email**: Recomendado manter habilitado para segurança

### 4.2 Configurar Templates de Email (Opcional)
1. Vá em **Authentication** → **Email Templates**
2. Personalize os templates se desejar
3. Configure **Site URL** para sua URL de produção quando fizer deploy

### 4.3 Configurar Redirect URLs
Para desenvolvimento:
```
http://localhost:5173/**
```

Para produção, adicione suas URLs:
```
https://seudominio.com/**
```

## 🔒 Passo 5: Configurar Políticas de Segurança

### 5.1 Verificar RLS
1. Vá em **Database** → **Tables**
2. Para cada tabela, verifique se **RLS enabled** está ativo
3. Se não estiver, clique na tabela e ative **Enable RLS**

### 5.2 Verificar Políticas
1. Clique em cada tabela
2. Vá na aba **Policies**
3. Deve haver políticas configuradas para cada operação (SELECT, INSERT, UPDATE, DELETE)

## 🧪 Passo 6: Testar a Configuração

### 6.1 Testar Conexão
1. Execute o projeto: `npm run dev`
2. Tente registrar um novo usuário
3. Faça login
4. Crie um card

### 6.2 Verificar Dados
1. No Supabase, vá em **Database** → **Tables**
2. Clique em **profiles** → deve aparecer seu usuário
3. Clique em **visual_cards** → deve aparecer seu card

## 🚨 Troubleshooting

### Erro: "Invalid API key"
- Verifique se copiou a key correta (anon public)
- Verifique se não há espaços extras
- Recrie o arquivo `.env.local`

### Erro: "relation does not exist"
- Execute novamente o script `database-setup.sql`
- Verifique se não houve erros na execução

### Erro: "Row Level Security policy violation"
- Verifique se as políticas RLS foram criadas
- Verifique se o usuário está autenticado

### Erro: "new row violates row-level security policy"
- Certifique-se que o trigger `handle_new_user` foi criado
- Tente fazer logout e login novamente

### Cards não aparecem
- Verifique se o card está ativo (`is_active = true`)
- Verifique as políticas da tabela `visual_cards`

## 📊 Monitoramento

### Visualizar Logs
1. **Database** → **Logs**
2. Filtre por tipo de log (Auth, Database, etc.)

### Verificar Uso
1. **Settings** → **Usage**
2. Monitore limites do plano gratuito

### Backup (Recomendado)
1. **Database** → **Backups**
2. Configure backups automáticos se necessário

## 🌐 Deploy em Produção

### Configurações Adicionais
1. Configure **Custom Domain** se tiver
2. Ajuste **Site URL** para sua URL de produção
3. Configure **Redirect URLs** corretas
4. Considere upgrade para plano pago se necessário

### Variáveis de Ambiente de Produção
Use as mesmas credenciais, mas configure corretamente na sua plataforma de deploy (Vercel, Netlify, etc.)

## 📞 Suporte

Se encontrar problemas:
1. Consulte a [documentação oficial do Supabase](https://supabase.com/docs)
2. Verifique o [Status do Supabase](https://status.supabase.com/)
3. Abra uma issue no repositório do projeto

---

**✅ Configuração completa! Seu VisualCard está pronto para uso.**