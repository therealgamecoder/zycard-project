-- ===============================================
-- CORREÇÃO URGENTE - Colunas Faltando
-- Execute este SQL PRIMEIRO antes do database-blog-features.sql
-- ===============================================

-- Adicionar coluna slug se não existir
ALTER TABLE public.visual_cards 
ADD COLUMN IF NOT EXISTS slug TEXT;

-- Adicionar coluna country se não existir  
ALTER TABLE public.visual_cards 
ADD COLUMN IF NOT EXISTS country TEXT;

-- Adicionar coluna background_image_url se não existir
ALTER TABLE public.visual_cards 
ADD COLUMN IF NOT EXISTS background_image_url TEXT;

-- Gerar slugs para cards existentes que não têm slug
UPDATE public.visual_cards 
SET slug = LOWER(REGEXP_REPLACE(REGEXP_REPLACE(name, '[áàâãäå]', 'a', 'g'), '[^a-z0-9\s-]', '', 'g')) 
           || '-' || SUBSTRING(id::text, 1, 8)
WHERE slug IS NULL OR slug = '';

-- Tornar slug obrigatório e único
ALTER TABLE public.visual_cards ALTER COLUMN slug SET NOT NULL;

-- Criar índice único para slug (se não existir)
CREATE UNIQUE INDEX IF NOT EXISTS visual_cards_slug_unique ON public.visual_cards(slug);

-- ===============================================
-- VERIFICAÇÃO
-- ===============================================

-- Verificar se as colunas foram criadas
SELECT column_name, data_type, is_nullable 
FROM information_schema.columns 
WHERE table_name = 'visual_cards' 
  AND column_name IN ('slug', 'country', 'background_image_url')
ORDER BY column_name;

-- Verificar se todos os cards têm slug
SELECT COUNT(*) as total_cards, 
       COUNT(slug) as cards_with_slug,
       COUNT(*) - COUNT(slug) as cards_without_slug
FROM public.visual_cards;