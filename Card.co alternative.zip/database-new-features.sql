-- ===============================================
-- NOVAS FUNCIONALIDADES - VisualCard
-- Execute este SQL após o database-setup.sql principal
-- ===============================================

-- Adicionar campo de país/localização na tabela visual_cards
ALTER TABLE public.visual_cards 
ADD COLUMN country TEXT;

-- Criar índice para melhor performance em consultas por país
CREATE INDEX IF NOT EXISTS idx_visual_cards_country ON public.visual_cards(country);

-- ===============================================
-- DADOS DE PAÍSES PARA SELEÇÃO
-- ===============================================

-- Criar tabela de países (opcional - para dropdown organizado)
CREATE TABLE IF NOT EXISTS public.countries (
    code TEXT PRIMARY KEY, -- ISO 3166-1 alpha-2 (BR, US, etc.)
    name TEXT NOT NULL,
    name_pt TEXT NOT NULL, -- Nome em português
    flag_emoji TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Inserir países mais comuns (focar no Brasil e principais)
INSERT INTO public.countries (code, name, name_pt, flag_emoji) VALUES
('BR', 'Brazil', 'Brasil', '🇧🇷'),
('US', 'United States', 'Estados Unidos', '🇺🇸'),
('PT', 'Portugal', 'Portugal', '🇵🇹'),
('ES', 'Spain', 'Espanha', '🇪🇸'),
('FR', 'France', 'França', '🇫🇷'),
('IT', 'Italy', 'Itália', '🇮🇹'),
('DE', 'Germany', 'Alemanha', '🇩🇪'),
('UK', 'United Kingdom', 'Reino Unido', '🇬🇧'),
('CA', 'Canada', 'Canadá', '🇨🇦'),
('AU', 'Australia', 'Austrália', '🇦🇺'),
('JP', 'Japan', 'Japão', '🇯🇵'),
('KR', 'South Korea', 'Coreia do Sul', '🇰🇷'),
('CN', 'China', 'China', '🇨🇳'),
('IN', 'India', 'Índia', '🇮🇳'),
('MX', 'Mexico', 'México', '🇲🇽'),
('AR', 'Argentina', 'Argentina', '🇦🇷'),
('CL', 'Chile', 'Chile', '🇨🇱'),
('CO', 'Colombia', 'Colômbia', '🇨🇴'),
('PE', 'Peru', 'Peru', '🇵🇪'),
('UY', 'Uruguay', 'Uruguai', '🇺🇾'),
('PY', 'Paraguay', 'Paraguai', '🇵🇾'),
('BO', 'Bolivia', 'Bolívia', '🇧🇴'),
('VE', 'Venezuela', 'Venezuela', '🇻🇪'),
('EC', 'Ecuador', 'Equador', '🇪🇨'),
('NL', 'Netherlands', 'Holanda', '🇳🇱'),
('BE', 'Belgium', 'Bélgica', '🇧🇪'),
('CH', 'Switzerland', 'Suíça', '🇨🇭'),
('AT', 'Austria', 'Áustria', '🇦🇹'),
('SE', 'Sweden', 'Suécia', '🇸🇪'),
('NO', 'Norway', 'Noruega', '🇳🇴'),
('DK', 'Denmark', 'Dinamarca', '🇩🇰'),
('FI', 'Finland', 'Finlândia', '🇫🇮'),
('PL', 'Poland', 'Polônia', '🇵🇱'),
('CZ', 'Czech Republic', 'República Tcheca', '🇨🇿'),
('HU', 'Hungary', 'Hungria', '🇭🇺'),
('RO', 'Romania', 'Romênia', '🇷🇴'),
('BG', 'Bulgaria', 'Bulgária', '🇧🇬'),
('HR', 'Croatia', 'Croácia', '🇭🇷'),
('RS', 'Serbia', 'Sérvia', '🇷🇸'),
('SI', 'Slovenia', 'Eslovênia', '🇸🇮'),
('SK', 'Slovakia', 'Eslováquia', '🇸🇰'),
('EE', 'Estonia', 'Estônia', '🇪🇪'),
('LV', 'Latvia', 'Letônia', '🇱🇻'),
('LT', 'Lithuania', 'Lituânia', '🇱🇹'),
('IE', 'Ireland', 'Irlanda', '🇮🇪'),
('IS', 'Iceland', 'Islândia', '🇮🇸'),
('MT', 'Malta', 'Malta', '🇲🇹'),
('CY', 'Cyprus', 'Chipre', '🇨🇾'),
('LU', 'Luxembourg', 'Luxemburgo', '🇱🇺'),
('MC', 'Monaco', 'Mônaco', '🇲🇨'),
('AD', 'Andorra', 'Andorra', '🇦🇩'),
('SM', 'San Marino', 'San Marino', '🇸🇲'),
('VA', 'Vatican City', 'Vaticano', '🇻🇦'),
('RU', 'Russia', 'Rússia', '🇷🇺'),
('UA', 'Ukraine', 'Ucrânia', '🇺🇦'),
('BY', 'Belarus', 'Bielorrússia', '🇧🇾'),
('MD', 'Moldova', 'Moldávia', '🇲🇩'),
('GE', 'Georgia', 'Geórgia', '🇬🇪'),
('AM', 'Armenia', 'Armênia', '🇦🇲'),
('AZ', 'Azerbaijan', 'Azerbaijão', '🇦🇿'),
('TR', 'Turkey', 'Turquia', '🇹🇷'),
('IL', 'Israel', 'Israel', '🇮🇱'),
('PS', 'Palestine', 'Palestina', '🇵🇸'),
('LB', 'Lebanon', 'Líbano', '🇱🇧'),
('SY', 'Syria', 'Síria', '🇸🇾'),
('JO', 'Jordan', 'Jordânia', '🇯🇴'),
('IQ', 'Iraq', 'Iraque', '🇮🇶'),
('IR', 'Iran', 'Irã', '🇮🇷'),
('SA', 'Saudi Arabia', 'Arábia Saudita', '🇸🇦'),
('AE', 'United Arab Emirates', 'Emirados Árabes Unidos', '🇦🇪'),
('QA', 'Qatar', 'Catar', '🇶🇦'),
('KW', 'Kuwait', 'Kuwait', '🇰🇼'),
('BH', 'Bahrain', 'Bahrein', '🇧🇭'),
('OM', 'Oman', 'Omã', '🇴🇲'),
('YE', 'Yemen', 'Iêmen', '🇾🇪'),
('EG', 'Egypt', 'Egito', '🇪🇬'),
('LY', 'Libya', 'Líbia', '🇱🇾'),
('TN', 'Tunisia', 'Tunísia', '🇹🇳'),
('DZ', 'Algeria', 'Argélia', '🇩🇿'),
('MA', 'Morocco', 'Marrocos', '🇲🇦'),
('ZA', 'South Africa', 'África do Sul', '🇿🇦'),
('NG', 'Nigeria', 'Nigéria', '🇳🇬'),
('KE', 'Kenya', 'Quênia', '🇰🇪'),
('ET', 'Ethiopia', 'Etiópia', '🇪🇹'),
('GH', 'Ghana', 'Gana', '🇬🇭'),
('UG', 'Uganda', 'Uganda', '🇺🇬'),
('TZ', 'Tanzania', 'Tanzânia', '🇹🇿'),
('RW', 'Rwanda', 'Ruanda', '🇷🇼'),
('SN', 'Senegal', 'Senegal', '🇸🇳'),
('CI', 'Ivory Coast', 'Costa do Marfim', '🇨🇮'),
('BF', 'Burkina Faso', 'Burkina Faso', '🇧🇫'),
('ML', 'Mali', 'Mali', '🇲🇱'),
('NE', 'Niger', 'Níger', '🇳🇪'),
('TD', 'Chad', 'Chade', '🇹🇩'),
('CF', 'Central African Republic', 'República Centro-Africana', '🇨🇫'),
('CM', 'Cameroon', 'Camarões', '🇨🇲'),
('GA', 'Gabon', 'Gabão', '🇬🇦'),
('CG', 'Republic of the Congo', 'República do Congo', '🇨🇬'),
('CD', 'Democratic Republic of the Congo', 'República Democrática do Congo', '🇨🇩'),
('AO', 'Angola', 'Angola', '🇦🇴'),
('ZM', 'Zambia', 'Zâmbia', '🇿🇲'),
('ZW', 'Zimbabwe', 'Zimbábue', '🇿🇼'),
('BW', 'Botswana', 'Botswana', '🇧🇼'),
('NA', 'Namibia', 'Namíbia', '🇳🇦'),
('SZ', 'Eswatini', 'Eswatini', '🇸🇿'),
('LS', 'Lesotho', 'Lesoto', '🇱🇸'),
('MW', 'Malawi', 'Malawi', '🇲🇼'),
('MZ', 'Mozambique', 'Moçambique', '🇲🇿'),
('MG', 'Madagascar', 'Madagascar', '🇲🇬'),
('MU', 'Mauritius', 'Maurício', '🇲🇺'),
('SC', 'Seychelles', 'Seicheles', '🇸🇨'),
('KM', 'Comoros', 'Comores', '🇰🇲'),
('DJ', 'Djibouti', 'Djibuti', '🇩🇯'),
('SO', 'Somalia', 'Somália', '🇸🇴'),
('ER', 'Eritrea', 'Eritreia', '🇪🇷'),
('SD', 'Sudan', 'Sudão', '🇸🇩'),
('SS', 'South Sudan', 'Sudão do Sul', '🇸🇸'),
('TH', 'Thailand', 'Tailândia', '🇹🇭'),
('VN', 'Vietnam', 'Vietnã', '🇻🇳'),
('MM', 'Myanmar', 'Mianmar', '🇲🇲'),
('KH', 'Cambodia', 'Camboja', '🇰🇭'),
('LA', 'Laos', 'Laos', '🇱🇦'),
('MY', 'Malaysia', 'Malásia', '🇲🇾'),
('SG', 'Singapore', 'Singapura', '🇸🇬'),
('ID', 'Indonesia', 'Indonésia', '🇮🇩'),
('PH', 'Philippines', 'Filipinas', '🇵🇭'),
('BN', 'Brunei', 'Brunei', '🇧🇳'),
('TL', 'East Timor', 'Timor-Leste', '🇹🇱'),
('PG', 'Papua New Guinea', 'Papua-Nova Guiné', '🇵🇬'),
('FJ', 'Fiji', 'Fiji', '🇫🇯'),
('SB', 'Solomon Islands', 'Ilhas Salomão', '🇸🇧'),
('VU', 'Vanuatu', 'Vanuatu', '🇻🇺'),
('NC', 'New Caledonia', 'Nova Caledônia', '🇳🇨'),
('PF', 'French Polynesia', 'Polinésia Francesa', '🇵🇫'),
('WS', 'Samoa', 'Samoa', '🇼🇸'),
('TO', 'Tonga', 'Tonga', '🇹🇴'),
('KI', 'Kiribati', 'Kiribati', '🇰🇮'),
('TV', 'Tuvalu', 'Tuvalu', '🇹🇻'),
('NR', 'Nauru', 'Nauru', '🇳🇷'),
('PW', 'Palau', 'Palau', '🇵🇼'),
('FM', 'Micronesia', 'Micronésia', '🇫🇲'),
('MH', 'Marshall Islands', 'Ilhas Marshall', '🇲🇭'),
('NZ', 'New Zealand', 'Nova Zelândia', '🇳🇿')
ON CONFLICT (code) DO NOTHING;

-- Enable RLS para a tabela de países
ALTER TABLE public.countries ENABLE ROW LEVEL SECURITY;

-- Política para permitir leitura pública dos países
CREATE POLICY "Countries are publicly readable" ON public.countries
    FOR SELECT USING (true);

-- Grant permissions para a tabela de países
GRANT SELECT ON public.countries TO anon, authenticated;

-- ===============================================
-- COMENTÁRIOS DE USO
-- ===============================================

/*
COMO USAR A LOCALIZAÇÃO:

1. O campo 'country' na tabela visual_cards armazena o código do país (ex: 'BR', 'US')
2. A tabela 'countries' contém os dados completos dos países
3. Para buscar cards de um país específico:
   SELECT * FROM visual_cards WHERE country = 'BR';
   
4. Para buscar cards com dados completos do país:
   SELECT vc.*, c.name_pt, c.flag_emoji 
   FROM visual_cards vc 
   LEFT JOIN countries c ON vc.country = c.code 
   WHERE vc.user_id = 'user_id_here';

5. O campo pode ser NULL (quando não informado)
*/