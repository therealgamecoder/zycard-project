-- ===============================================
-- BLOG FEATURES - Versão Completa e Corrigida
-- Execute este SQL (inclui todas as correções necessárias)
-- ===============================================

-- PRIMEIRO: Verificar e criar colunas necessárias (exceto slug - será criado manualmente)
DO $$ 
BEGIN
    -- Verificar e criar coluna country
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name='visual_cards' AND column_name='country') THEN
        ALTER TABLE public.visual_cards ADD COLUMN country TEXT;
    END IF;
    
    -- Verificar e criar coluna background_image_url
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name='visual_cards' AND column_name='background_image_url') THEN
        ALTER TABLE public.visual_cards ADD COLUMN background_image_url TEXT;
    END IF;
END $$;

-- Adicionar campos de customização de fundo (se não existirem)
ALTER TABLE public.visual_cards 
ADD COLUMN IF NOT EXISTS background_color TEXT DEFAULT '#3b82f6';

ALTER TABLE public.visual_cards 
ADD COLUMN IF NOT EXISTS background_gradient TEXT;

ALTER TABLE public.visual_cards 
ADD COLUMN IF NOT EXISTS custom_css TEXT;

-- Criar tabela de posts do blog
CREATE TABLE IF NOT EXISTS public.blog_posts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    card_id UUID REFERENCES public.visual_cards(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    excerpt TEXT,
    featured_image_url TEXT,
    slug TEXT NOT NULL,
    is_published BOOLEAN DEFAULT false NOT NULL,
    published_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_blog_posts_card_id ON public.blog_posts(card_id);
CREATE INDEX IF NOT EXISTS idx_blog_posts_slug ON public.blog_posts(card_id, slug);
CREATE INDEX IF NOT EXISTS idx_blog_posts_published ON public.blog_posts(is_published, published_at);

-- Constraint única para slug por card
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'blog_posts_card_slug_unique'
    ) THEN
        ALTER TABLE public.blog_posts 
        ADD CONSTRAINT blog_posts_card_slug_unique UNIQUE (card_id, slug);
    END IF;
END $$;

-- Enable RLS
ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;

-- Políticas para blog_posts
DROP POLICY IF EXISTS "Users can manage posts of own cards" ON public.blog_posts;
CREATE POLICY "Users can manage posts of own cards" ON public.blog_posts
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND user_id = auth.uid()
        )
    );

DROP POLICY IF EXISTS "Anyone can view published posts of active cards" ON public.blog_posts;
CREATE POLICY "Anyone can view published posts of active cards" ON public.blog_posts
    FOR SELECT USING (
        is_published = true AND EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND is_active = true
        )
    );

-- Criar função para atualizar timestamp (se não existir)
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger para atualizar timestamp
DROP TRIGGER IF EXISTS update_blog_posts_updated_at ON public.blog_posts;
CREATE TRIGGER update_blog_posts_updated_at 
    BEFORE UPDATE ON public.blog_posts
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Grant permissions
GRANT ALL ON public.blog_posts TO anon, authenticated;

-- ===============================================
-- VERIFICAÇÃO FINAL
-- ===============================================

-- Verificar se a tabela foi criada
SELECT 
    table_name,
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns 
WHERE table_name = 'blog_posts'
ORDER BY ordinal_position;

-- Verificar políticas RLS
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual
FROM pg_policies 
WHERE tablename = 'blog_posts';

-- Testar inserção (vai falhar por RLS, mas confirma estrutura)
-- INSERT INTO public.blog_posts (card_id, title, content, slug) 
-- VALUES ('00000000-0000-0000-0000-000000000000', 'Teste', 'Conteúdo teste', 'teste');

SELECT 'Blog features instaladas com sucesso!' as status;