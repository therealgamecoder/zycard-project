// Platform constants and configuration

export const APP_NAME = 'VisualCard'
export const APP_DESCRIPTION = 'Crie cards profissionais personalizados e compartilhe seu perfil'

// Validation constants
export const VALIDATION = {
  NAME: {
    MIN_LENGTH: 2,
    MAX_LENGTH: 50
  },
  SLUG: {
    MIN_LENGTH: 3,
    MAX_LENGTH: 30,
    PATTERN: /^[a-z0-9-]+$/
  },
  DESCRIPTION: {
    MAX_LENGTH: 500
  },
  EMAIL: {
    PATTERN: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  },
  PASSWORD: {
    MIN_LENGTH: 8,
    PATTERN: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&]{8,}$/
  }
}

// Social platforms supported
export const SOCIAL_PLATFORMS = [
  { id: 'instagram', name: 'Instagram', icon: 'instagram' },
  { id: 'twitter', name: 'Twitter/X', icon: 'twitter' },
  { id: 'linkedin', name: 'LinkedIn', icon: 'linkedin' },
  { id: 'facebook', name: 'Facebook', icon: 'facebook' },
  { id: 'youtube', name: 'YouTube', icon: 'youtube' },
  { id: 'tiktok', name: 'TikTok', icon: 'music' },
  { id: 'github', name: 'GitHub', icon: 'github' },
  { id: 'website', name: 'Website', icon: 'globe' },
  { id: 'email', name: 'Email', icon: 'mail' },
  { id: 'phone', name: 'Telefone', icon: 'phone' }
] as const

// Theme options
export const THEMES = [
  { id: 'light', name: 'Claro', icon: 'sun' },
  { id: 'dark', name: 'Escuro', icon: 'moon' },
  { id: 'system', name: 'Sistema', icon: 'monitor' }
] as const

// Emoji options for blog reactions
export const REACTION_EMOJIS = [
  '👍', '❤️', '😂', '😮', '😢', '😡', '🚀', '🎉', '🔥', '💯'
] as const

// File upload constraints
export const UPLOAD_CONSTRAINTS = {
  MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  ALLOWED_TYPES: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
  MAX_WIDTH: 1200,
  MAX_HEIGHT: 1200
}

// Rate limiting
export const RATE_LIMITS = {
  CARD_CREATION: 5, // max cards per user
  BLOG_POSTS_PER_DAY: 10,
  REACTIONS_PER_POST: 1
}

// Error messages
export const ERROR_MESSAGES = {
  INVALID_EMAIL: 'Email inválido',
  WEAK_PASSWORD: 'Senha deve ter pelo menos 8 caracteres, incluindo letras e números',
  INVALID_NAME: 'Nome deve ter entre 2 e 50 caracteres',
  INVALID_SLUG: 'Slug deve ter entre 3 e 30 caracteres (apenas letras, números e hífens)',
  SLUG_TAKEN: 'Este slug já está em uso. Escolha outro.',
  NETWORK_ERROR: 'Erro de conexão. Tente novamente.',
  UNAUTHORIZED: 'Você não tem permissão para realizar esta ação',
  NOT_FOUND: 'Recurso não encontrado',
  SERVER_ERROR: 'Erro interno do servidor'
}

// Success messages
export const SUCCESS_MESSAGES = {
  CARD_CREATED: 'Card criado com sucesso!',
  CARD_UPDATED: 'Card atualizado com sucesso!',
  CARD_DELETED: 'Card excluído com sucesso!',
  LINK_COPIED: 'Link copiado para a área de transferência!',
  PROFILE_UPDATED: 'Perfil atualizado com sucesso!',
  POST_PUBLISHED: 'Post publicado com sucesso!',
  REACTION_ADDED: 'Reação adicionada!'
}