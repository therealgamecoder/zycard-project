export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          name: string
          avatar_url?: string
          bio?: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          name: string
          avatar_url?: string
          bio?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          name?: string
          avatar_url?: string
          bio?: string
          created_at?: string
          updated_at?: string
        }
      }
      visual_cards: {
        Row: {
          id: string
          user_id: string
          name: string
          description?: string
          avatar_url?: string
          background_image_url?: string
          background_color?: string
          background_gradient?: string
          custom_css?: string
          country?: string
          slug: string
          is_active: boolean
          theme: 'light' | 'dark' | 'auto'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          description?: string
          avatar_url?: string
          background_image_url?: string
          background_color?: string
          background_gradient?: string
          custom_css?: string
          country?: string
          slug: string
          is_active?: boolean
          theme?: 'light' | 'dark' | 'auto'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          description?: string
          avatar_url?: string
          background_image_url?: string
          background_color?: string
          background_gradient?: string
          custom_css?: string
          country?: string
          slug?: string
          is_active?: boolean
          theme?: 'light' | 'dark' | 'auto'
          created_at?: string
          updated_at?: string
        }
      }
      countries: {
        Row: {
          code: string
          name: string
          name_pt: string
          flag_emoji: string
          created_at: string
        }
        Insert: {
          code: string
          name: string
          name_pt: string
          flag_emoji: string
          created_at?: string
        }
        Update: {
          code?: string
          name?: string
          name_pt?: string
          flag_emoji?: string
          created_at?: string
        }
      }
      social_links: {
        Row: {
          id: string
          card_id: string
          platform: string
          url: string
          display_name: string
          order_index: number
          is_active: boolean
          created_at: string
        }
        Insert: {
          id?: string
          card_id: string
          platform: string
          url: string
          display_name: string
          order_index: number
          is_active?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          card_id?: string
          platform?: string
          url?: string
          display_name?: string
          order_index?: number
          is_active?: boolean
          created_at?: string
        }
      }
      site_redirectors: {
        Row: {
          id: string
          card_id: string
          title: string
          url: string
          image_url?: string
          description?: string
          order_index: number
          is_active: boolean
          created_at: string
        }
        Insert: {
          id?: string
          card_id: string
          title: string
          url: string
          image_url?: string
          description?: string
          order_index: number
          is_active?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          card_id?: string
          title?: string
          url?: string
          image_url?: string
          description?: string
          order_index?: number
          is_active?: boolean
          created_at?: string
        }
      }
      blog_posts: {
        Row: {
          id: string
          card_id: string
          title: string
          content: string
          excerpt?: string
          featured_image_url?: string
          slug: string
          is_published: boolean
          published_at?: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          card_id: string
          title: string
          content: string
          excerpt?: string
          featured_image_url?: string
          slug: string
          is_published?: boolean
          published_at?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          card_id?: string
          title?: string
          content?: string
          excerpt?: string
          featured_image_url?: string
          slug?: string
          is_published?: boolean
          published_at?: string
          created_at?: string
          updated_at?: string
        }
      }
      blog_categories: {
        Row: {
          id: string
          card_id: string
          name: string
          slug: string
          color: string
          created_at: string
        }
        Insert: {
          id?: string
          card_id: string
          name: string
          slug: string
          color?: string
          created_at?: string
        }
        Update: {
          id?: string
          card_id?: string
          name?: string
          slug?: string
          color?: string
          created_at?: string
        }
      }
      blog_post_categories: {
        Row: {
          id: string
          post_id: string
          category_id: string
        }
        Insert: {
          id?: string
          post_id: string
          category_id: string
        }
        Update: {
          id?: string
          post_id?: string
          category_id?: string
        }
      }
      blog_reactions: {
        Row: {
          id: string
          post_id: string
          user_id: string
          emoji: string
          created_at: string
        }
        Insert: {
          id?: string
          post_id: string
          user_id: string
          emoji: string
          created_at?: string
        }
        Update: {
          id?: string
          post_id?: string
          user_id?: string
          emoji?: string
          created_at?: string
        }
      }
    }
  }
}