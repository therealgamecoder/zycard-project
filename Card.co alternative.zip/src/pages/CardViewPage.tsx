import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useCountries } from '../hooks/useCountries'
import { LoadingSpinner } from '../components/LoadingSpinner'
import { 
  ExternalLink, 
  Mail, 
  Phone, 
  MessageCircle,
  Calendar,
  MapPin,
  FileText,
  User
} from 'lucide-react'

interface VisualCard {
  id: string
  name: string
  description?: string
  avatar_url?: string
  background_image_url?: string
  background_color?: string
  background_gradient?: string
  country?: string
  slug: string
  is_active: boolean
  theme: 'light' | 'dark' | 'auto'
  created_at: string
  updated_at: string
}

interface BlogPost {
  id: string
  title: string
  content: string
  excerpt?: string
  featured_image_url?: string
  slug: string
  is_published: boolean
  published_at?: string
  created_at: string
}

export const CardViewPage = () => {
  const { slug } = useParams<{ slug: string }>()
  const { getCountryDisplay } = useCountries()
  const [card, setCard] = useState<VisualCard | null>(null)
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([])
  const [activeTab, setActiveTab] = useState<'about' | 'blog'>('about')
  const [loading, setLoading] = useState(true)
  const [notFound, setNotFound] = useState(false)

  useEffect(() => {
    if (slug) {
      fetchCard()
    }
  }, [slug])

  const fetchCard = async () => {
    try {
      const { data, error } = await supabase
        .from('visual_cards')
        .select('*')
        .eq('slug', slug)
        .eq('is_active', true)
        .single()

      if (error || !data) {
        setNotFound(true)
        return
      }

      setCard(data)
      await fetchBlogPosts(data.id)
    } catch (error) {
      setNotFound(true)
    } finally {
      setLoading(false)
    }
  }

  const fetchBlogPosts = async (cardId: string) => {
    try {
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('card_id', cardId)
        .eq('is_published', true)
        .order('published_at', { ascending: false })
        .limit(10)

      if (!error && data) {
        setBlogPosts(data)
      }
    } catch (error) {
      console.error('Error fetching blog posts:', error)
    }
  }

  if (loading) {
    return <LoadingSpinner />
  }

  if (notFound || !card) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-dark-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-gray-300 dark:text-gray-600 mb-4">404</h1>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
            Card não encontrado
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            O card que você está procurando não existe ou foi desativado.
          </p>
        </div>
      </div>
    )
  }

  // Get background style
  const getBackgroundStyle = () => {
    if (card.background_image_url) {
      return {
        backgroundImage: `url(${card.background_image_url})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }
    } else if (card.background_gradient) {
      return { background: card.background_gradient }
    } else {
      return { backgroundColor: card.background_color || '#3b82f6' }
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-900 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Card Container */}
        <div className="bg-white dark:bg-dark-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
          {/* Header Section with Custom Background */}
          <div 
            className="relative px-8 py-16 text-center"
            style={getBackgroundStyle()}
          >
            <div className="absolute inset-0 bg-black bg-opacity-20"></div>
            
            <div className="relative z-10">
            {/* Avatar */}
            <div className="mb-6">
              {card.avatar_url ? (
                <img
                  src={card.avatar_url}
                  alt={card.name}
                    className="w-32 h-32 rounded-full mx-auto border-4 border-white shadow-lg object-cover"
                />
              ) : (
                  <div className="w-32 h-32 rounded-full mx-auto border-4 border-white shadow-lg bg-white flex items-center justify-center">
                    <span className="text-gray-600 font-bold text-4xl">
                    {card.name.charAt(0).toUpperCase()}
                  </span>
                </div>
              )}
            </div>

            {/* Name and Description */}
              <h1 className="text-4xl font-bold text-white mb-3 drop-shadow-lg">
              {card.name}
            </h1>

            {card.description && (
                <p className="text-white text-lg max-w-2xl mx-auto mb-4 drop-shadow">
                {card.description}
              </p>
            )}

              {/* Country */}
              {card.country && (
                <div className="flex items-center justify-center space-x-2 text-white">
                  <MapPin className="h-5 w-5" />
                  <span className="text-lg drop-shadow">
                    {getCountryDisplay(card.country)}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="border-b border-gray-200 dark:border-gray-700">
            <nav className="flex space-x-8 px-8">
              <button
                onClick={() => setActiveTab('about')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'about'
                    ? 'border-primary-500 text-primary-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <User className="h-4 w-4" />
                  <span>Sobre</span>
                </div>
              </button>
              
              <button
                onClick={() => setActiveTab('blog')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'blog'
                    ? 'border-primary-500 text-primary-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <FileText className="h-4 w-4" />
                  <span>Blog</span>
                  {blogPosts.length > 0 && (
                    <span className="bg-primary-100 text-primary-600 text-xs px-2 py-1 rounded-full">
                      {blogPosts.length}
                    </span>
                  )}
                </div>
              </button>
            </nav>
          </div>

          {/* Content Section */}
          <div className="p-8">
            {activeTab === 'about' && (
              <div className="space-y-8">
                {/* About Content */}
                <div>
                  <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                    Sobre {card.name}
                  </h2>
                  
                  {card.description ? (
                    <p className="text-gray-600 dark:text-gray-400 text-lg leading-relaxed">
                      {card.description}
                    </p>
                  ) : (
                    <p className="text-gray-500 dark:text-gray-500 italic">
                      Nenhuma descrição disponível.
                    </p>
                  )}
                </div>

                {/* Future Features Preview */}
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    🚀 Em breve
                  </h3>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/50 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <ExternalLink className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">Links Sociais</span>
                    </div>
                    
                    <div className="text-center">
                      <div className="w-12 h-12 bg-green-100 dark:bg-green-900/50 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <Mail className="h-6 w-6 text-green-600 dark:text-green-400" />
                      </div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">Contato</span>
                    </div>
                    
                    <div className="text-center">
                      <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/50 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <Calendar className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                      </div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">Agenda</span>
                    </div>
                    
                    <div className="text-center">
                      <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/50 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <MapPin className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                      </div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">Localização</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'blog' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">
                    Blog
                  </h2>
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {blogPosts.length} {blogPosts.length === 1 ? 'post' : 'posts'}
                  </span>
                </div>

                {blogPosts.length > 0 ? (
                  <div className="space-y-6">
                    {blogPosts.map((post) => (
                      <article
                        key={post.id}
                        className="bg-gray-50 dark:bg-dark-700 rounded-lg p-6 hover:shadow-md transition-shadow"
                      >
                        {post.featured_image_url && (
                          <img
                            src={post.featured_image_url}
                            alt={post.title}
                            className="w-full h-48 object-cover rounded-lg mb-4"
                          />
                        )}
                        
                        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                          {post.title}
                        </h3>
                        
                        {post.excerpt && (
                          <p className="text-gray-600 dark:text-gray-400 mb-4">
                            {post.excerpt}
                          </p>
                        )}
                        
                        <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                          <time dateTime={post.published_at || post.created_at}>
                            {new Date(post.published_at || post.created_at).toLocaleDateString('pt-BR', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </time>
                          <button className="text-primary-600 hover:text-primary-700 font-medium">
                            Ler mais →
                          </button>
                        </div>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                      <FileText className="h-8 w-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                      Nenhum post ainda
                    </h3>
                    <p className="text-gray-500 dark:text-gray-400">
                      {card.name} ainda não publicou nenhum post no blog.
                    </p>
                </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-gray-500 dark:text-gray-400 text-sm">
            Criado com ❤️ usando VisualCard
          </p>
        </div>
      </div>
    </div>
  )
}