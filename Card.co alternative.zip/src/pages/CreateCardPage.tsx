import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Navbar } from '../components/Navbar'
import { useAuth } from '../hooks/useAuth'
import { supabase, sanitizeInput } from '../lib/supabase'
import { 
  User, 
  Image as ImageIcon, 
  FileText, 
  Save,
  ArrowLeft 
} from 'lucide-react'
import toast from 'react-hot-toast'

export const CreateCardPage = () => {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    description: '',
    avatar_url: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setLoading(true)

    try {
      // Sanitize inputs
      const cleanName = sanitizeInput(formData.name)
      const cleanSlug = sanitizeInput(formData.slug.toLowerCase().replace(/[^a-z0-9-]/g, ''))
      const cleanDescription = sanitizeInput(formData.description)

      // Validation
      if (cleanName.length < 2 || cleanName.length > 50) {
        toast.error('Nome deve ter entre 2 e 50 caracteres')
        return
      }

      if (cleanSlug.length < 3 || cleanSlug.length > 30) {
        toast.error('Slug deve ter entre 3 e 30 caracteres (apenas letras, números e hífens)')
        return
      }

      // Check if slug is already taken
      const { data: existingCard } = await supabase
        .from('visual_cards')
        .select('id')
        .eq('slug', cleanSlug)
        .single()

      if (existingCard) {
        toast.error('Este slug já está em uso. Escolha outro.')
        return
      }

      // Create card
      const { error } = await supabase
        .from('visual_cards')
        .insert({
          user_id: user.id,
          name: cleanName,
          slug: cleanSlug,
          description: cleanDescription || null,
          avatar_url: formData.avatar_url || null,
          is_active: true,
          theme: 'auto'
        })

      if (error) {
        toast.error('Erro ao criar card: ' + error.message)
        return
      }

      toast.success('Card criado com sucesso!')
      navigate('/dashboard')
    } catch (error) {
      toast.error('Erro inesperado ao criar card')
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))

    // Auto-generate slug from name
    if (name === 'name') {
      const slug = value
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, '')
        .replace(/\s+/g, '-')
        .substring(0, 30)
      
      setFormData(prev => ({
        ...prev,
        slug
      }))
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-900">
      <Navbar />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => navigate('/dashboard')}
            className="inline-flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-4"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Voltar ao dashboard</span>
          </button>
          
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Criar novo VisualCard
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Preencha as informações básicas do seu card profissional
          </p>
        </div>

        {/* Form */}
        <div className="bg-white dark:bg-dark-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Name Field */}
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <div className="flex items-center space-x-2">
                  <User className="h-4 w-4" />
                  <span>Nome do Card *</span>
                </div>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                required
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-dark-700 dark:text-white transition-colors"
                placeholder="Seu nome ou nome da empresa"
              />
            </div>

            {/* Slug Field */}
            <div>
              <label htmlFor="slug" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                URL do Card *
              </label>
              <div className="flex">
                <span className="inline-flex items-center px-3 border border-r-0 border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-dark-600 text-gray-500 dark:text-gray-400 text-sm rounded-l-lg">
                  {window.location.origin}/card/
                </span>
                <input
                  type="text"
                  id="slug"
                  name="slug"
                  required
                  value={formData.slug}
                  onChange={handleChange}
                  className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-r-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-dark-700 dark:text-white transition-colors"
                  placeholder="meu-card"
                  pattern="[a-z0-9-]+"
                />
              </div>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Apenas letras minúsculas, números e hífens. Este será seu link único.
              </p>
            </div>

            {/* Avatar URL Field */}
            <div>
              <label htmlFor="avatar_url" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <div className="flex items-center space-x-2">
                  <ImageIcon className="h-4 w-4" />
                  <span>URL da Foto de Perfil</span>
                </div>
              </label>
              <input
                type="url"
                id="avatar_url"
                name="avatar_url"
                value={formData.avatar_url}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-dark-700 dark:text-white transition-colors"
                placeholder="https://exemplo.com/minha-foto.jpg"
              />
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Cole a URL de uma imagem hospedada online (opcional)
              </p>
            </div>

            {/* Description Field */}
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <div className="flex items-center space-x-2">
                  <FileText className="h-4 w-4" />
                  <span>Descrição</span>
                </div>
              </label>
              <textarea
                id="description"
                name="description"
                rows={4}
                value={formData.description}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-dark-700 dark:text-white transition-colors resize-none"
                placeholder="Conte um pouco sobre você ou sua empresa..."
              />
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Uma breve descrição que aparecerá no seu card (opcional)
              </p>
            </div>

            {/* Submit Button */}
            <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200 dark:border-gray-700">
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-dark-700 transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center space-x-2 px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Save className="h-4 w-4" />
                <span>{loading ? 'Criando...' : 'Criar Card'}</span>
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  )
}