import { useState, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { useCountries } from '../hooks/useCountries'
import { Navbar } from '../components/Navbar'
import { EditCardModal } from '../components/EditCardModal'
import { BlogManager } from '../components/BlogManager'

import { 
  Plus, 
  Eye, 
  Edit, 
  Share2, 
  MoreVertical, 
  ExternalLink, 
  Copy, 
  Trash2,
  MapPin,
  FileText,
  X
} from 'lucide-react'
import { supabase } from '../lib/supabase'
import toast from 'react-hot-toast'

interface VisualCard {
  id: string
  name: string
  description?: string
  avatar_url?: string
  background_image_url?: string
  background_color?: string
  background_gradient?: string
  custom_css?: string
  country?: string
  slug: string
  is_active: boolean
  theme: 'light' | 'dark' | 'auto'
  created_at: string
  updated_at: string
}

export const Dashboard = () => {
  const { user } = useAuth()
  const { getCountryDisplay, loading: countriesLoading } = useCountries()
  const [cards, setCards] = useState<VisualCard[]>([])
  const [loading, setLoading] = useState(true)
  const [cardMenuOpen, setCardMenuOpen] = useState<string | null>(null)
  const [editingCard, setEditingCard] = useState<VisualCard | null>(null)
  const [managingBlog, setManagingBlog] = useState<VisualCard | null>(null)

  useEffect(() => {
    if (user) {
      fetchCards()
    }
  }, [user])

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (cardMenuOpen) {
        const target = event.target as Element
        if (!target.closest('.card-menu')) {
          setCardMenuOpen(null)
        }
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [cardMenuOpen])

  const fetchCards = async () => {
    try {
      const { data, error } = await supabase
        .from('visual_cards')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })

      if (error) {
        toast.error('Erro ao carregar cards')
        return
      }

      setCards(data || [])
    } catch (error) {
      toast.error('Erro inesperado ao carregar cards')
    } finally {
      setLoading(false)
    }
  }

  const copyCardLink = (slug: string) => {
    const url = `${window.location.origin}/card/${slug}`
    navigator.clipboard.writeText(url)
    toast.success('Link copiado!')
    setCardMenuOpen(null)
  }

  const toggleCardStatus = async (cardId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('visual_cards')
        .update({ is_active: !currentStatus })
        .eq('id', cardId)

      if (error) {
        toast.error('Erro ao atualizar status do card')
        return
      }

      setCards(prev => prev.map(card => 
        card.id === cardId 
          ? { ...card, is_active: !currentStatus }
          : card
      ))

      toast.success(`Card ${!currentStatus ? 'ativado' : 'desativado'}`)
      setCardMenuOpen(null)
    } catch (error) {
      toast.error('Erro inesperado')
    }
  }

  const deleteCard = async (cardId: string) => {
    if (!confirm('Tem certeza que deseja excluir este card? Esta ação não pode ser desfeita.')) {
      return
    }

    try {
      const { error } = await supabase
        .from('visual_cards')
        .delete()
        .eq('id', cardId)

      if (error) {
        toast.error('Erro ao excluir card')
        return
      }

      setCards(prev => prev.filter(card => card.id !== cardId))
      toast.success('Card excluído com sucesso')
      setCardMenuOpen(null)
    } catch (error) {
      toast.error('Erro inesperado ao excluir card')
    }
  }

  const handleEditCard = (card: VisualCard) => {
    setEditingCard(card)
    setCardMenuOpen(null)
  }

  const handleUpdateCard = (updatedCard: VisualCard) => {
    setCards(prev => prev.map(card => 
      card.id === updatedCard.id ? updatedCard : card
    ))
  }

  const handleManageBlog = (card: VisualCard) => {
    setManagingBlog(card)
    setCardMenuOpen(null)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-dark-900">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-900">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Olá, {user?.user_metadata?.name || user?.email?.split('@')[0]}! 👋
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Gerencie seus cards e compartilhe seu perfil profissional
          </p>
        </div>

        {/* Cards Grid */}
        {cards.length === 0 ? (
          /* Empty State */
          <div className="text-center py-16">
            <div className="mx-auto w-24 h-24 bg-gray-200 dark:bg-dark-700 rounded-full flex items-center justify-center mb-6">
              <Plus className="h-12 w-12 text-gray-400 dark:text-gray-500" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Crie seu primeiro VisualCard
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
              Comece criando um card profissional para compartilhar suas informações, 
              links sociais e muito mais.
            </p>
            <Link
              to="/create-card"
              className="inline-flex items-center space-x-2 px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-medium transition-colors"
            >
              <Plus className="h-5 w-5" />
              <span>Criar meu primeiro card</span>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Create New Card Button */}
            <Link
              to="/create-card"
              className="group relative block w-full border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-12 text-center hover:border-gray-400 dark:hover:border-gray-500 transition-colors"
            >
              <Plus className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500 group-hover:text-gray-500 dark:group-hover:text-gray-400" />
              <span className="mt-2 block text-sm font-medium text-gray-900 dark:text-white">
                Criar novo card
              </span>
            </Link>

            {/* Cards List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {cards.map((card) => (
                <div
                  key={card.id}
                  className="bg-white dark:bg-dark-800 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-200 dark:border-gray-700 overflow-visible relative"
                >
                  {/* Background Header */}
                  <div 
                    className="h-24 relative overflow-hidden"
                    style={{
                      ...(card.background_image_url 
                        ? {
                            backgroundImage: `url(${card.background_image_url})`,
                            backgroundSize: 'cover',
                            backgroundPosition: 'center'
                          }
                        : card.background_gradient
                        ? { background: card.background_gradient }
                        : { backgroundColor: card.background_color || '#3b82f6' }
                      )
                    }}
                  >
                    <div className="absolute inset-0 bg-black bg-opacity-20"></div>
                  </div>
                  
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        {card.avatar_url ? (
                          <img
                            src={card.avatar_url}
                            alt={card.name}
                            className="w-12 h-12 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center">
                            <span className="text-primary-600 dark:text-primary-400 font-medium text-lg">
                              {card.name.charAt(0).toUpperCase()}
                            </span>
                          </div>
                        )}
                        <div>
                          <h3 className="font-semibold text-gray-900 dark:text-white">
                            {card.name}
                          </h3>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            @{card.slug}
                          </p>
                        </div>
                      </div>

                      {/* Card Menu */}
                      <div className="relative card-menu">
                        <button
                          onClick={() => setCardMenuOpen(cardMenuOpen === card.id ? null : card.id)}
                          className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-dark-700 transition-colors"
                        >
                          <MoreVertical className="h-5 w-5 text-gray-400" />
                        </button>

                        {cardMenuOpen === card.id && (
                          <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-dark-700 rounded-lg shadow-lg border border-gray-200 dark:border-gray-600 py-1 z-50">
                            <Link
                              to={`/card/${card.slug}`}
                              className="flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-600"
                              onClick={() => setCardMenuOpen(null)}
                            >
                              <Eye className="h-4 w-4" />
                              <span>Visualizar</span>
                            </Link>
                            
                            <button
                              onClick={() => handleEditCard(card)}
                              className="flex items-center space-x-2 w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-600"
                            >
                              <Edit className="h-4 w-4" />
                              <span>Editar</span>
                            </button>
                            
                            <button
                              onClick={() => handleManageBlog(card)}
                              className="flex items-center space-x-2 w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-600"
                            >
                              <FileText className="h-4 w-4" />
                              <span>Gerenciar Blog</span>
                            </button>
                            
                            <button
                              onClick={() => copyCardLink(card.slug)}
                              className="flex items-center space-x-2 w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-600"
                            >
                              <Copy className="h-4 w-4" />
                              <span>Copiar link</span>
                            </button>
                            
                            <button
                              onClick={() => toggleCardStatus(card.id, card.is_active)}
                              className="flex items-center space-x-2 w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-600"
                            >
                              <div className={`h-4 w-4 rounded-full ${card.is_active ? 'bg-green-500' : 'bg-gray-400'}`} />
                              <span>{card.is_active ? 'Desativar' : 'Ativar'}</span>
                            </button>
                            
                            <div className="border-t border-gray-200 dark:border-gray-600 my-1" />
                            
                            <button
                              onClick={() => deleteCard(card.id)}
                              className="flex items-center space-x-2 w-full px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-dark-600"
                            >
                              <Trash2 className="h-4 w-4" />
                              <span>Excluir</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {card.description && (
                      <p className="text-gray-600 dark:text-gray-400 text-sm mb-3 line-clamp-2">
                        {card.description}
                      </p>
                    )}

                    {card.country && (
                      <div className="flex items-center space-x-2 mb-4">
                        <MapPin className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {countriesLoading ? 'Carregando...' : getCountryDisplay(card.country)}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className={`h-2 w-2 rounded-full ${card.is_active ? 'bg-green-500' : 'bg-gray-400'}`} />
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {card.is_active ? 'Ativo' : 'Inativo'}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Link
                          to={`/card/${card.slug}`}
                          className="p-2 text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                          title="Ver card"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Link>
                        <button
                          onClick={() => copyCardLink(card.slug)}
                          className="p-2 text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                          title="Compartilhar"
                        >
                          <Share2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            
          </div>
        )}
      </main>

      {/* Edit Card Modal */}
      {editingCard && (
        <EditCardModal
          card={editingCard}
          isOpen={!!editingCard}
          onClose={() => setEditingCard(null)}
          onUpdate={handleUpdateCard}
        />
      )}

      {/* Blog Manager Modal */}
      {managingBlog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-dark-800 rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Blog do {managingBlog.name}
                </h2>
                <button
                  onClick={() => setManagingBlog(null)}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-dark-700 rounded-lg transition-colors"
                >
                  <X className="h-5 w-5 text-gray-400" />
                </button>
              </div>
              
              <BlogManager 
                cardId={managingBlog.id}
                cardSlug={managingBlog.slug}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}