import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

interface Country {
  code: string
  name: string
  name_pt: string
  flag_emoji: string
  created_at: string
}

export const useCountries = () => {
  const [countries, setCountries] = useState<Country[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchCountries()
  }, [])

  const fetchCountries = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('countries')
        .select('*')
        .order('name_pt', { ascending: true })

      if (error) {
        setError('Erro ao carregar países')
        return
      }

      setCountries(data || [])
    } catch (err) {
      setError('Erro inesperado ao carregar países')
    } finally {
      setLoading(false)
    }
  }

  const getCountryByCode = (code: string | null | undefined): Country | null => {
    if (!code) return null
    return countries.find(country => country.code === code) || null
  }

  const getCountryDisplay = (code: string | null | undefined): string => {
    const country = getCountryByCode(code)
    if (!country) return ''
    return `${country.flag_emoji} ${country.name_pt}`
  }

  return {
    countries,
    loading,
    error,
    getCountryByCode,
    getCountryDisplay,
    refetch: fetchCountries
  }
}