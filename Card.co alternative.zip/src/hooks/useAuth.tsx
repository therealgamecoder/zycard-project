import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import type { User, Session, AuthError } from '@supabase/supabase-js'
import { supabase, sanitizeInput, validateEmail, validatePassword } from '../lib/supabase'
import toast from 'react-hot-toast'

interface AuthContextType {
  user: User | null
  session: Session | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<{ error: AuthError | null }>
  signUp: (email: string, password: string, name: string) => Promise<{ error: AuthError | null }>
  signOut: () => Promise<void>
  resetPassword: (email: string) => Promise<{ error: AuthError | null }>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

interface AuthProviderProps {
  children: ReactNode
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setUser(session?.user ?? null)
      setLoading(false)
    })

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      setSession(session)
      setUser(session?.user ?? null)
      setLoading(false)

      if (event === 'SIGNED_IN') {
        toast.success('Bem-vindo!')
      } else if (event === 'SIGNED_OUT') {
        toast.success('Logout realizado com sucesso!')
      }
    })

    return () => subscription.unsubscribe()
  }, [])

  const signIn = async (email: string, password: string) => {
    try {
      // Input validation and sanitization
      const cleanEmail = sanitizeInput(email.toLowerCase())
      
      if (!validateEmail(cleanEmail)) {
        toast.error('Email inválido')
        return { error: new Error('Invalid email') as AuthError }
      }

      if (!validatePassword(password)) {
        toast.error('Senha deve ter pelo menos 8 caracteres, incluindo letras e números')
        return { error: new Error('Invalid password') as AuthError }
      }

      const { error } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password,
      })

      if (error) {
        toast.error('Erro ao fazer login: ' + error.message)
        return { error }
      }

      return { error: null }
    } catch (error) {
      const authError = error as AuthError
      toast.error('Erro inesperado ao fazer login')
      return { error: authError }
    }
  }

  const signUp = async (email: string, password: string, name: string) => {
    try {
      // Input validation and sanitization
      const cleanEmail = sanitizeInput(email.toLowerCase())
      const cleanName = sanitizeInput(name)
      
      if (!validateEmail(cleanEmail)) {
        toast.error('Email inválido')
        return { error: new Error('Invalid email') as AuthError }
      }

      if (!validatePassword(password)) {
        toast.error('Senha deve ter pelo menos 8 caracteres, incluindo letras e números')
        return { error: new Error('Invalid password') as AuthError }
      }

      if (cleanName.length < 2 || cleanName.length > 50) {
        toast.error('Nome deve ter entre 2 e 50 caracteres')
        return { error: new Error('Invalid name') as AuthError }
      }

      const { error } = await supabase.auth.signUp({
        email: cleanEmail,
        password,
        options: {
          data: {
            name: cleanName,
          },
        },
      })

      if (error) {
        toast.error('Erro ao criar conta: ' + error.message)
        return { error }
      }

      toast.success('Conta criada! Verifique seu email para ativar.')
      return { error: null }
    } catch (error) {
      const authError = error as AuthError
      toast.error('Erro inesperado ao criar conta')
      return { error: authError }
    }
  }

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut()
      if (error) {
        toast.error('Erro ao fazer logout')
      }
    } catch (error) {
      toast.error('Erro inesperado ao fazer logout')
    }
  }

  const resetPassword = async (email: string) => {
    try {
      const cleanEmail = sanitizeInput(email.toLowerCase())
      
      if (!validateEmail(cleanEmail)) {
        toast.error('Email inválido')
        return { error: new Error('Invalid email') as AuthError }
      }

      const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
        redirectTo: `${window.location.origin}/reset-password`,
      })

      if (error) {
        toast.error('Erro ao enviar email de recuperação')
        return { error }
      }

      toast.success('Email de recuperação enviado!')
      return { error: null }
    } catch (error) {
      const authError = error as AuthError
      toast.error('Erro inesperado')
      return { error: authError }
    }
  }

  const value = {
    user,
    session,
    loading,
    signIn,
    signUp,
    signOut,
    resetPassword,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}