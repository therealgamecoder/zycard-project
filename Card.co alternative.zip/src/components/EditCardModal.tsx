import { useState, useRef } from 'react'
import { X, Upload, Camera, Trash2, MapPin, Palette, Image } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useCountries } from '../hooks/useCountries'
import toast from 'react-hot-toast'

interface VisualCard {
  id: string
  name: string
  description?: string
  avatar_url?: string
  background_image_url?: string
  background_color?: string
  background_gradient?: string
  custom_css?: string
  country?: string
  slug: string
  is_active: boolean
  theme: 'light' | 'dark' | 'auto'
  created_at: string
  updated_at: string
}

interface EditCardModalProps {
  card: VisualCard
  isOpen: boolean
  onClose: () => void
  onUpdate: (updatedCard: VisualCard) => void
}

export const EditCardModal = ({ card, isOpen, onClose, onUpdate }: EditCardModalProps) => {
  const { countries, loading: countriesLoading, getCountryDisplay } = useCountries()
  const [formData, setFormData] = useState({
    name: card.name,
    description: card.description || '',
    theme: card.theme,
    country: card.country || '',
    background_color: card.background_color || '#3b82f6',
    background_gradient: card.background_gradient || '',
    custom_css: card.custom_css || ''
  })
  const [backgroundType, setBackgroundType] = useState<'color' | 'gradient' | 'image'>(
    card.background_image_url ? 'image' : 
    card.background_gradient ? 'gradient' : 'color'
  )
  const [avatarFile, setAvatarFile] = useState<File | null>(null)
  const [backgroundFile, setBackgroundFile] = useState<File | null>(null)
  const [avatarPreview, setAvatarPreview] = useState<string | null>(card.avatar_url || null)
  const [backgroundPreview, setBackgroundPreview] = useState<string | null>(card.background_image_url || null)
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)

  const avatarInputRef = useRef<HTMLInputElement>(null)
  const backgroundInputRef = useRef<HTMLInputElement>(null)

  if (!isOpen) return null

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast.error('A imagem deve ter no máximo 5MB')
        return
      }
      
      setAvatarFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setAvatarPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleBackgroundChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        toast.error('A imagem de fundo deve ter no máximo 10MB')
        return
      }
      
      setBackgroundFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setBackgroundPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const uploadImage = async (file: File, bucket: string, path: string): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop()
      const fileName = `${path}-${Date.now()}.${fileExt}`
      
      // Try to upload file
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from(bucket)
        .upload(fileName, file, { 
          cacheControl: '3600',
          upsert: true
        })

      if (uploadError) {
        console.error('Upload error:', uploadError)
        toast.error(`Erro no upload: ${uploadError.message}`)
        return null
      }

      const { data } = supabase.storage
        .from(bucket)
        .getPublicUrl(fileName)

      return data.publicUrl
    } catch (error) {
      console.error('Error uploading image:', error)
      toast.error('Erro inesperado no upload')
      return null
    }
  }

  const handleSave = async () => {
    setSaving(true)
    
    try {
      let avatarUrl = card.avatar_url
      let backgroundUrl = card.background_image_url

      // Upload new avatar if selected
      if (avatarFile) {
        setUploading(true)
        const uploadedAvatarUrl = await uploadImage(avatarFile, 'avatars', `card-avatar-${card.id}`)
        if (uploadedAvatarUrl) {
          avatarUrl = uploadedAvatarUrl
        } else {
          toast.error('Erro ao fazer upload da foto de perfil')
          return
        }
      }

      // Upload new background if selected
      if (backgroundFile) {
        setUploading(true)
        const uploadedBackgroundUrl = await uploadImage(backgroundFile, 'backgrounds', `card-bg-${card.id}`)
        if (uploadedBackgroundUrl) {
          backgroundUrl = uploadedBackgroundUrl
        } else {
          toast.error('Erro ao fazer upload da foto de fundo')
          return
        }
      }

      setUploading(false)

      // Update card in database
      const updateData: any = {
        name: formData.name.trim(),
        description: formData.description.trim() || null,
        theme: formData.theme,
        country: formData.country || null,
        avatar_url: avatarUrl,
        custom_css: formData.custom_css.trim() || null,
        updated_at: new Date().toISOString()
      }

      // Handle background based on type
      if (backgroundType === 'image') {
        updateData.background_image_url = backgroundUrl
        updateData.background_color = null
        updateData.background_gradient = null
      } else if (backgroundType === 'gradient') {
        updateData.background_gradient = formData.background_gradient || null
        updateData.background_color = null
        updateData.background_image_url = null
      } else {
        updateData.background_color = formData.background_color
        updateData.background_gradient = null
        updateData.background_image_url = null
      }

      const { data, error } = await supabase
        .from('visual_cards')
        .update(updateData)
        .eq('id', card.id)
        .select()
        .single()

      if (error) {
        toast.error('Erro ao salvar alterações')
        return
      }

      const updatedCard = { ...card, ...data }
      onUpdate(updatedCard)
      toast.success('Card atualizado com sucesso!')
      onClose()

    } catch (error) {
      console.error('Error saving card:', error)
      toast.error('Erro inesperado ao salvar')
    } finally {
      setSaving(false)
      setUploading(false)
    }
  }

  const removeAvatar = () => {
    setAvatarFile(null)
    setAvatarPreview(null)
  }

  const removeBackground = () => {
    setBackgroundFile(null)
    setBackgroundPreview(null)
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-dark-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Editar Card
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-dark-700 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Background Customization Section */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
              Personalização de Fundo
            </label>
            
            {/* Background Type Selector */}
            <div className="flex space-x-2 mb-4">
              <button
                type="button"
                onClick={() => setBackgroundType('color')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm ${
                  backgroundType === 'color'
                    ? 'bg-primary-100 text-primary-700 border border-primary-300'
                    : 'bg-gray-100 text-gray-700 border border-gray-300 hover:bg-gray-200'
                }`}
              >
                <Palette className="h-4 w-4" />
                <span>Cor</span>
              </button>
              <button
                type="button"
                onClick={() => setBackgroundType('gradient')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm ${
                  backgroundType === 'gradient'
                    ? 'bg-primary-100 text-primary-700 border border-primary-300'
                    : 'bg-gray-100 text-gray-700 border border-gray-300 hover:bg-gray-200'
                }`}
              >
                <div className="h-4 w-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
                <span>Gradiente</span>
              </button>
              <button
                type="button"
                onClick={() => setBackgroundType('image')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm ${
                  backgroundType === 'image'
                    ? 'bg-primary-100 text-primary-700 border border-primary-300'
                    : 'bg-gray-100 text-gray-700 border border-gray-300 hover:bg-gray-200'
                }`}
              >
                <Image className="h-4 w-4" />
                <span>Imagem</span>
              </button>
            </div>
            {/* Background Options */}
            {backgroundType === 'color' && (
              <div className="space-y-4">
                <div>
                  <label htmlFor="background_color" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Cor de Fundo
                  </label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="color"
                      id="background_color"
                      name="background_color"
                      value={formData.background_color}
                      onChange={handleInputChange}
                      className="h-10 w-20 rounded border border-gray-300 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={formData.background_color}
                      onChange={(e) => setFormData(prev => ({ ...prev, background_color: e.target.value }))}
                      className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-dark-700 dark:text-white"
                      placeholder="#3b82f6"
                    />
                  </div>
                </div>
                <div 
                  className="h-20 rounded-lg border-2 border-dashed border-gray-300"
                  style={{ backgroundColor: formData.background_color }}
                >
                  <div className="h-full flex items-center justify-center">
                    <span className="text-white text-sm font-medium bg-black bg-opacity-50 px-2 py-1 rounded">
                      Preview
                    </span>
                  </div>
                </div>
              </div>
            )}

            {backgroundType === 'gradient' && (
              <div className="space-y-4">
                <div>
                  <label htmlFor="background_gradient" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    CSS Gradiente
                  </label>
                  <textarea
                    id="background_gradient"
                    name="background_gradient"
                    value={formData.background_gradient}
                    onChange={handleInputChange}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-dark-700 dark:text-white resize-none"
                    placeholder="linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Use CSS gradient syntax. Exemplos: linear-gradient, radial-gradient
                  </p>
                </div>
                <div 
                  className="h-20 rounded-lg border-2 border-dashed border-gray-300"
                  style={{ background: formData.background_gradient || 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}
                >
                  <div className="h-full flex items-center justify-center">
                    <span className="text-white text-sm font-medium bg-black bg-opacity-50 px-2 py-1 rounded">
                      Preview
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
                    'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
                    'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)'
                  ].map((gradient, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, background_gradient: gradient }))}
                      className="h-8 rounded border-2 border-gray-300 hover:border-primary-500 transition-colors"
                      style={{ background: gradient }}
                    />
                  ))}
                </div>
              </div>
            )}

            {backgroundType === 'image' && (
              <div className="space-y-4">
                <div className="relative h-32 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg overflow-hidden">
                  {backgroundPreview && (
                    <img
                      src={backgroundPreview}
                      alt="Preview da foto de fundo"
                      className="w-full h-full object-cover"
                    />
                  )}
                  <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                    <div className="flex space-x-2">
                      <button
                        type="button"
                        onClick={() => backgroundInputRef.current?.click()}
                        className="p-2 bg-white bg-opacity-90 hover:bg-opacity-100 rounded-full transition-all"
                        title="Alterar foto de fundo"
                      >
                        <Camera className="h-5 w-5 text-gray-700" />
                      </button>
                      {backgroundPreview && (
                        <button
                          type="button"
                          onClick={removeBackground}
                          className="p-2 bg-red-500 bg-opacity-90 hover:bg-opacity-100 rounded-full transition-all"
                          title="Remover foto de fundo"
                        >
                          <Trash2 className="h-5 w-5 text-white" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <input
                  ref={backgroundInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleBackgroundChange}
                  className="hidden"
                />

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => backgroundInputRef.current?.click()}
                    className="flex items-center space-x-2 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-dark-700 transition-colors"
                  >
                    <Upload className="h-4 w-4" />
                    <span className="text-sm">Escolher imagem</span>
                  </button>
                  <span className="text-xs text-gray-500">
                    PNG, JPG até 10MB
                  </span>
                </div>
                
                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                  <p className="text-sm text-blue-800 dark:text-blue-300 font-medium mb-1">
                    📐 Tamanhos recomendados:
                  </p>
                  <ul className="text-xs text-blue-700 dark:text-blue-400 space-y-1">
                    <li>• Desktop: <strong>1920x1080px</strong> (16:9)</li>
                    <li>• Mobile: <strong>1080x1920px</strong> (9:16)</li>
                    <li>• Quadrado: <strong>1080x1080px</strong> (1:1)</li>
                    <li>• Banner: <strong>1920x600px</strong> (16:5)</li>
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* Avatar Section */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
              Foto de Perfil
            </label>
            <div className="flex items-center space-x-4">
              <div className="relative">
                {avatarPreview ? (
                  <img
                    src={avatarPreview}
                    alt="Preview da foto de perfil"
                    className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-lg"
                  />
                ) : (
                  <div className="w-20 h-20 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center border-4 border-white shadow-lg">
                    <span className="text-primary-600 dark:text-primary-400 font-medium text-2xl">
                      {formData.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                )}
                <button
                  onClick={() => avatarInputRef.current?.click()}
                  className="absolute -bottom-1 -right-1 p-2 bg-primary-500 hover:bg-primary-600 rounded-full text-white transition-colors"
                  title="Alterar foto de perfil"
                >
                  <Camera className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-2">
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarChange}
                  className="hidden"
                />
                <button
                  onClick={() => avatarInputRef.current?.click()}
                  className="flex items-center space-x-2 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-dark-700 transition-colors"
                >
                  <Upload className="h-4 w-4" />
                  <span className="text-sm">Alterar foto</span>
                </button>
                {avatarPreview && (
                  <button
                    onClick={removeAvatar}
                    className="flex items-center space-x-2 px-4 py-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                    <span className="text-sm">Remover</span>
                  </button>
                )}
                <p className="text-xs text-gray-500">PNG, JPG até 5MB</p>
              </div>
            </div>
          </div>

          {/* Basic Info */}
          <div className="grid grid-cols-1 gap-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Nome do Card
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-dark-700 dark:text-white"
                required
              />
            </div>

            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Descrição
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-dark-700 dark:text-white resize-none"
                placeholder="Adicione uma descrição para seu card..."
              />
            </div>

            <div>
              <label htmlFor="theme" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Tema
              </label>
              <select
                id="theme"
                name="theme"
                value={formData.theme}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-dark-700 dark:text-white"
              >
                <option value="auto">Automático</option>
                <option value="light">Claro</option>
                <option value="dark">Escuro</option>
              </select>
            </div>

            <div>
              <label htmlFor="country" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4" />
                  <span>País/Localização</span>
                </div>
              </label>
              <select
                id="country"
                name="country"
                value={formData.country}
                onChange={handleInputChange}
                disabled={countriesLoading}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 dark:bg-dark-700 dark:text-white disabled:opacity-50"
              >
                <option value="">Selecione um país...</option>
                {countries.map((country) => (
                  <option key={country.code} value={country.code}>
                    {country.flag_emoji} {country.name_pt}
                  </option>
                ))}
              </select>
              {countriesLoading && (
                <p className="text-xs text-gray-500 mt-1">Carregando países...</p>
              )}
              {formData.country && !countriesLoading && (
                <div className="mt-2 flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                  <MapPin className="h-4 w-4" />
                  <span>{getCountryDisplay(formData.country)}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end space-x-3 p-6 border-t border-gray-200 dark:border-gray-700">
          <button
            onClick={onClose}
            disabled={saving || uploading}
            className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-700 rounded-md transition-colors disabled:opacity-50"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            disabled={saving || uploading || !formData.name.trim()}
            className="px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-md transition-colors disabled:opacity-50 flex items-center space-x-2"
          >
            {(saving || uploading) && (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            )}
            <span>{saving ? 'Salvando...' : uploading ? 'Upload...' : 'Salvar'}</span>
          </button>
        </div>
      </div>
    </div>
  )
}