import { 
  Instagram, 
  Twitter, 
  Linkedin, 
  Github, 
  Link2, 
  FileText, 
  Mail, 
  MapPin,
  Clock
} from 'lucide-react'

const upcomingFeatures = [
  {
    icon: Link2,
    title: 'Links Sociais',
    description: 'Instagram, Twitter, LinkedIn, GitHub e muito mais',
    color: 'bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400'
  },
  {
    icon: FileText,
    title: 'Blog',
    description: 'Publique artigos e posts diretamente no seu card',
    color: 'bg-green-100 text-green-600 dark:bg-green-900/20 dark:text-green-400'
  },
  {
    icon: Mail,
    title: 'Contato',
    description: 'Formulário de contato e informações de comunicação',
    color: 'bg-purple-100 text-purple-600 dark:bg-purple-900/20 dark:text-purple-400'
  },
  {
    icon: MapPin,
    title: 'Localização',
    description: 'Mostrar país e região de forma destacada',
    color: 'bg-orange-100 text-orange-600 dark:bg-orange-900/20 dark:text-orange-400'
  }
]

export const DevelopmentFeatures = () => {
  return (
    <div className="bg-white dark:bg-dark-800 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Clock className="h-6 w-6 text-yellow-500" />
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
          Funcionalidades em desenvolvimento
        </h2>
      </div>
      
      <p className="text-gray-600 dark:text-gray-400 mb-6">
        Em breve você poderá adicionar links sociais, redirecionadores e muito mais!
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {upcomingFeatures.map((feature, index) => {
          const IconComponent = feature.icon
          return (
            <div
              key={index}
              className="flex items-start space-x-3 p-4 bg-gray-50 dark:bg-dark-700 rounded-lg border border-gray-200 dark:border-gray-600"
            >
              <div className={`p-2 rounded-lg ${feature.color}`}>
                <IconComponent className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {feature.description}
                </p>
              </div>
            </div>
          )
        })}
      </div>

      <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/10 rounded-lg border border-blue-200 dark:border-blue-800">
        <div className="flex items-start space-x-2">
          <div className="bg-blue-500 rounded-full p-1 mt-0.5">
            <div className="w-2 h-2 bg-white rounded-full"></div>
          </div>
          <div>
            <p className="text-sm font-medium text-blue-900 dark:text-blue-300">
              Localização já disponível!
            </p>
            <p className="text-sm text-blue-700 dark:text-blue-400 mt-1">
              Você já pode adicionar seu país nas configurações do card. As outras funcionalidades chegam em breve!
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}