-- VisualCard Database Setup
-- Execute estas queries no SQL Editor do Supabase

-- Enable RLS (Row Level Security)
ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

-- Create profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
    email TEXT NOT NULL,
    name TEXT NOT NULL,
    avatar_url TEXT,
    bio TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Create visual_cards table
CREATE TABLE IF NOT EXISTS public.visual_cards (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    avatar_url TEXT,
    background_image_url TEXT,
    slug TEXT UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT true NOT NULL,
    theme TEXT DEFAULT 'auto' CHECK (theme IN ('light', 'dark', 'auto')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Create social_links table
CREATE TABLE IF NOT EXISTS public.social_links (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    card_id UUID REFERENCES public.visual_cards(id) ON DELETE CASCADE NOT NULL,
    platform TEXT NOT NULL,
    url TEXT NOT NULL,
    display_name TEXT NOT NULL,
    order_index INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN DEFAULT true NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Create site_redirectors table
CREATE TABLE IF NOT EXISTS public.site_redirectors (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    card_id UUID REFERENCES public.visual_cards(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    image_url TEXT,
    description TEXT,
    order_index INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN DEFAULT true NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Create blog_posts table
CREATE TABLE IF NOT EXISTS public.blog_posts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    card_id UUID REFERENCES public.visual_cards(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    is_published BOOLEAN DEFAULT false NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Create blog_reactions table
CREATE TABLE IF NOT EXISTS public.blog_reactions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    post_id UUID REFERENCES public.blog_posts(id) ON DELETE CASCADE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    emoji TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    UNIQUE(post_id, user_id, emoji)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_visual_cards_user_id ON public.visual_cards(user_id);
CREATE INDEX IF NOT EXISTS idx_visual_cards_slug ON public.visual_cards(slug);
CREATE INDEX IF NOT EXISTS idx_social_links_card_id ON public.social_links(card_id);
CREATE INDEX IF NOT EXISTS idx_site_redirectors_card_id ON public.site_redirectors(card_id);
CREATE INDEX IF NOT EXISTS idx_blog_posts_card_id ON public.blog_posts(card_id);
CREATE INDEX IF NOT EXISTS idx_blog_reactions_post_id ON public.blog_reactions(post_id);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visual_cards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.social_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_redirectors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blog_reactions ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for profiles
CREATE POLICY "Users can view own profile" ON public.profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
    FOR INSERT WITH CHECK (auth.uid() = id);

-- Create RLS policies for visual_cards
CREATE POLICY "Users can view own cards" ON public.visual_cards
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Anyone can view active cards" ON public.visual_cards
    FOR SELECT USING (is_active = true);

CREATE POLICY "Users can create own cards" ON public.visual_cards
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own cards" ON public.visual_cards
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own cards" ON public.visual_cards
    FOR DELETE USING (auth.uid() = user_id);

-- Create RLS policies for social_links
CREATE POLICY "Users can manage social links of own cards" ON public.social_links
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND user_id = auth.uid()
        )
    );

CREATE POLICY "Anyone can view social links of active cards" ON public.social_links
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND is_active = true
        )
    );

-- Create RLS policies for site_redirectors
CREATE POLICY "Users can manage redirectors of own cards" ON public.site_redirectors
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND user_id = auth.uid()
        )
    );

CREATE POLICY "Anyone can view redirectors of active cards" ON public.site_redirectors
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND is_active = true
        )
    );

-- Create RLS policies for blog_posts
CREATE POLICY "Users can manage posts of own cards" ON public.blog_posts
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND user_id = auth.uid()
        )
    );

CREATE POLICY "Anyone can view published posts of active cards" ON public.blog_posts
    FOR SELECT USING (
        is_published = true AND EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND is_active = true
        )
    );

-- Create RLS policies for blog_reactions
CREATE POLICY "Users can manage own reactions" ON public.blog_reactions
    FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Anyone can view reactions on published posts" ON public.blog_reactions
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.blog_posts bp
            JOIN public.visual_cards vc ON bp.card_id = vc.id
            WHERE bp.id = post_id AND bp.is_published = true AND vc.is_active = true
        )
    );

-- Create function to handle user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, name)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1))
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user registration
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create function to update timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at columns
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_visual_cards_updated_at BEFORE UPDATE ON public.visual_cards
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_blog_posts_updated_at BEFORE UPDATE ON public.blog_posts
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon, authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated;

-- ===============================================
-- MIGRATION: Add background_image_url field
-- Execute ONLY if upgrading existing database
-- ===============================================
-- ALTER TABLE public.visual_cards 
-- ADD COLUMN background_image_url TEXT;