# VisualCard - Plataforma Profissional de Cards de Perfil

Uma plataforma moderna e segura para criar cards de perfis profissionais personalizados, inspirada no Carrd.co mas com funcionalidades avançadas como blog integrado e sistema de reações.

## 🚀 Características

### ✅ Funcionalidades Implementadas
- **Autenticação Segura**: Sistema completo de login, registro e recuperação de senha
- **Dashboard Intuitivo**: Interface para gerenciar todos os seus cards
- **Criador de Cards**: Ferramenta para criar cards profissionais personalizados
- **Modo Escuro/Claro**: Alternância entre temas com persistência
- **Visualização Pública**: Cards compartilháveis via URL única
- **Segurança Avançada**: Sanitização de inputs, validações e RLS no banco
- **Design Responsivo**: Interface otimizada para desktop e mobile

### 🚧 Em Desenvolvimento
- **Links Sociais**: Adicionar 5-10 links para redes sociais com ícones dinâmicos
- **Redirecionadores**: Botões customizados para sites externos
- **Sistema de Blog**: Posts com reações por emoji
- **Upload de Imagens**: Sistema próprio para hospedar avatares
- **Temas Personalizados**: Cores e layouts customizáveis

## 🛠 Tecnologias Utilizadas

- **Frontend**: React 19 + TypeScript + Vite
- **Estilização**: Tailwind CSS + CSS personalizado
- **Banco de Dados**: Supabase (PostgreSQL)
- **Autenticação**: Supabase Auth
- **Ícones**: Lucide React
- **Notificações**: React Hot Toast
- **Roteamento**: React Router DOM

## 📦 Instalação e Configuração

### 1. Clone o repositório
```bash
git clone <url-do-repositorio>
cd Card.co\ alternative
```

### 2. Instale as dependências
```bash
npm install
```

### 3. Configure o Supabase

#### 3.1 Crie um projeto no Supabase
1. Acesse [https://supabase.com](https://supabase.com)
2. Crie uma nova conta ou faça login
3. Crie um novo projeto

#### 3.2 Configure o banco de dados
1. No painel do Supabase, vá em **SQL Editor**
2. Execute todo o conteúdo do arquivo `database-setup.sql`
3. Isso criará todas as tabelas, índices, políticas RLS e triggers necessários

#### 3.3 Configure as variáveis de ambiente
Crie um arquivo `.env.local` na raiz do projeto:

```env
VITE_SUPABASE_URL=sua_supabase_url_aqui
VITE_SUPABASE_ANON_KEY=sua_supabase_anon_key_aqui
```

**⚠️ IMPORTANTE**: Nunca commite o arquivo `.env.local` no git. Ele já está no `.gitignore`.

### 4. Execute o projeto
```bash
npm run dev
```

A aplicação estará disponível em `http://localhost:5173`

## 🔒 Segurança

Este projeto implementa diversas medidas de segurança:

### Frontend
- **Sanitização de Inputs**: Todos os inputs são sanitizados antes do envio
- **Validação de Dados**: Validação client-side com regex para email e senha
- **Headers Seguros**: CSP e outras configurações de segurança
- **Prevenção XSS**: Escape de caracteres especiais

### Backend (Supabase)
- **Row Level Security (RLS)**: Controle granular de acesso aos dados
- **Políticas de Acesso**: Usuários só podem acessar seus próprios dados
- **Triggers de Segurança**: Validações automáticas no banco
- **Autenticação JWT**: Tokens seguros para autenticação

### Validações Implementadas
- **Email**: Formato válido obrigatório
- **Senha**: Mínimo 8 caracteres, letras e números
- **Slug**: Apenas letras minúsculas, números e hífens
- **Nomes**: Entre 2 e 50 caracteres
- **URLs**: Formato válido para avatares e links

## 📝 Como Usar

### 1. Criando uma Conta
1. Acesse a página de registro
2. Preencha: nome completo, email e senha segura
3. Confirme sua conta via email

### 2. Criando seu Primeiro Card
1. No dashboard, clique em "Criar Card"
2. Preencha:
   - **Nome do Card**: Seu nome ou empresa
   - **Slug**: URL única (ex: joao-silva)
   - **Foto**: URL de uma imagem online
   - **Descrição**: Texto sobre você
3. Clique em "Criar Card"

### 3. Gerenciando Cards
No dashboard você pode:
- **Visualizar**: Ver como o card aparece publicamente
- **Editar**: Modificar informações (em breve)
- **Copiar Link**: Compartilhar o card
- **Ativar/Desativar**: Controlar visibilidade
- **Excluir**: Remover o card permanentemente

### 4. Compartilhando
Cada card tem uma URL única:
```
https://seudominio.com/card/seu-slug
```

## 🎨 Personalização

### Temas
- **Claro**: Interface com fundo branco
- **Escuro**: Interface com fundo escuro
- **Sistema**: Segue a preferência do sistema operacional

### Responsividade
- **Desktop**: Layout completo com sidebar
- **Tablet**: Layout adaptado com menu colapsível
- **Mobile**: Interface otimizada para toque

## 📊 Estrutura do Banco de Dados

### Tabelas Principais
- **profiles**: Perfis dos usuários
- **visual_cards**: Cards criados pelos usuários
- **social_links**: Links para redes sociais (futuro)
- **site_redirectors**: Botões para sites externos (futuro)
- **blog_posts**: Posts do blog (futuro)
- **blog_reactions**: Reações aos posts (futuro)

### Relacionamentos
- Um usuário pode ter múltiplos cards
- Cada card pode ter múltiplos links sociais e redirecionadores
- Cards podem ter múltiplos posts de blog
- Posts podem ter múltiplas reações

## 🚀 Deploy

### Vercel (Recomendado)
1. Conecte seu repositório ao Vercel
2. Configure as variáveis de ambiente
3. Deploy automático a cada push

### Netlify
1. Conecte seu repositório ao Netlify
2. Configure: `npm run build` como build command
3. Configure `dist` como publish directory

### Variáveis de Ambiente para Produção
```env
VITE_SUPABASE_URL=sua_url_de_producao
VITE_SUPABASE_ANON_KEY=sua_key_de_producao
```

## 🤝 Contribuindo

### Roadmap de Funcionalidades
- [ ] Sistema de links sociais
- [ ] Redirecionadores customizados
- [ ] Blog integrado com reações
- [ ] Upload de imagens próprio
- [ ] Temas personalizáveis
- [ ] Analytics básicos
- [ ] Exportação de dados
- [ ] API pública

### Como Contribuir
1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## 🆘 Suporte

### Problemas Comuns

**Erro de conexão com Supabase**
- Verifique se as variáveis de ambiente estão corretas
- Confirme se o banco foi configurado com o script SQL

**Card não aparece na visualização pública**
- Verifique se o card está ativo
- Confirme se o slug está correto

**Erro de autenticação**
- Limpe o localStorage do browser
- Verifique se o email foi confirmado

### Contato
Para dúvidas ou sugestões, abra uma issue no repositório.

---

**Feito com ❤️ para a comunidade de desenvolvedores**