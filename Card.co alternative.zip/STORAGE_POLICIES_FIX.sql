-- ===============================================
-- CORREÇÃO URGENTE: Storage RLS Policies
-- Execute este SQL no painel do Supabase em Storage > Policies
-- ===============================================

-- IMPORTANTE: Execute estes comandos na área de STORAGE POLICIES, não no SQL Editor normal!

-- ===============================================
-- POLÍTICAS PARA BUCKET 'avatars'
-- ===============================================

-- 1. Política de INSERT (Upload)
CREATE POLICY "Allow authenticated users to upload avatars" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'avatars'
);

-- 2. Política de SELECT (Visualização pública)
CREATE POLICY "Allow public access to avatars" ON storage.objects
FOR SELECT TO public
USING (bucket_id = 'avatars');

-- 3. Política de UPDATE (Atualização)
CREATE POLICY "Allow users to update their avatars" ON storage.objects
FOR UPDATE TO authenticated
USING (bucket_id = 'avatars');

-- 4. Política de DELETE (Exclusão)
CREATE POLICY "Allow users to delete their avatars" ON storage.objects
FOR DELETE TO authenticated
USING (bucket_id = 'avatars');

-- ===============================================
-- POLÍTICAS PARA BUCKET 'backgrounds'
-- ===============================================

-- 1. Política de INSERT (Upload)
CREATE POLICY "Allow authenticated users to upload backgrounds" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'backgrounds'
);

-- 2. Política de SELECT (Visualização pública)
CREATE POLICY "Allow public access to backgrounds" ON storage.objects
FOR SELECT TO public
USING (bucket_id = 'backgrounds');

-- 3. Política de UPDATE (Atualização)
CREATE POLICY "Allow users to update their backgrounds" ON storage.objects
FOR UPDATE TO authenticated
USING (bucket_id = 'backgrounds');

-- 4. Política de DELETE (Exclusão)
CREATE POLICY "Allow users to delete their backgrounds" ON storage.objects
FOR DELETE TO authenticated
USING (bucket_id = 'backgrounds');

-- ===============================================
-- INSTRUÇÕES DE USO:
-- ===============================================

/*
COMO APLICAR:

1. Vá para o painel do Supabase
2. Clique em "Storage" no menu lateral
3. Clique na aba "Policies" 
4. Clique em "New Policy"
5. Cole cada política uma por vez
6. Clique em "Review" e depois "Save Policy"

OU

1. Vá para "SQL Editor"
2. Cole todo este arquivo
3. Execute (mas pode dar erro, prefira o método acima)

VERIFICAR SE FUNCIONOU:
- Teste o upload de uma imagem
- Se não der erro "violates row-level security policy" = ✅ funcionou
*/