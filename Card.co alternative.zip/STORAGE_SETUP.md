# Configuração do Storage - Supabase

Execute os seguintes comandos no **Storage** do painel do Supabase:

## 1. Criar Buckets

Vá em **Storage** > **Create a new bucket** e crie os seguintes buckets:

### Bucket: `avatars`
- **Name:** `avatars`
- **Public:** ✅ Sim (marcar como público)

### Bucket: `backgrounds`
- **Name:** `backgrounds`  
- **Public:** ✅ Sim (marcar como público)

## 2. Configurar Políticas de Segurança (RLS)

Vá em **Storage** > **Policies** e adicione as seguintes políticas para cada bucket:

### Para o bucket `avatars`:

#### Política de Upload (INSERT):
```sql
CREATE POLICY "Users can upload avatars" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'avatars' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);
```

#### Política de Visualização (SELECT):
```sql
CREATE POLICY "Avatar images are publicly accessible" ON storage.objects
FOR SELECT USING (bucket_id = 'avatars');
```

#### Política de Atualização (UPDATE):
```sql
CREATE POLICY "Users can update own avatars" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'avatars' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);
```

#### Política de Exclusão (DELETE):
```sql
CREATE POLICY "Users can delete own avatars" ON storage.objects
FOR DELETE USING (
  bucket_id = 'avatars' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);
```

### Para o bucket `backgrounds`:

#### Política de Upload (INSERT):
```sql
CREATE POLICY "Users can upload backgrounds" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'backgrounds' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);
```

#### Política de Visualização (SELECT):
```sql
CREATE POLICY "Background images are publicly accessible" ON storage.objects
FOR SELECT USING (bucket_id = 'backgrounds');
```

#### Política de Atualização (UPDATE):
```sql
CREATE POLICY "Users can update own backgrounds" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'backgrounds' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);
```

#### Política de Exclusão (DELETE):
```sql
CREATE POLICY "Users can delete own backgrounds" ON storage.objects
FOR DELETE USING (
  bucket_id = 'backgrounds' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);
```

## 3. Estrutura de Pastas

As imagens serão organizadas automaticamente da seguinte forma:

```
avatars/
  └── card-avatar-{card_id}-{timestamp}.{ext}

backgrounds/
  └── card-bg-{card_id}-{timestamp}.{ext}
```

## Observações

- As imagens de avatar têm limite de **5MB**
- As imagens de fundo têm limite de **10MB**
- Formatos aceitos: PNG, JPG, JPEG, WEBP
- Todas as imagens são públicas após o upload
- As políticas garantem que apenas o dono pode fazer upload/editar/deletar suas próprias imagens