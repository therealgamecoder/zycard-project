# 🚨 CORREÇÃO URGENTE - Storage RLS Error

## **ERRO:** "new row violates row-level security policy"

### ⚡ **SOLUÇÃO RÁPIDA (5 minutos):**

#### 1. **Acesse o Supabase Dashboard**
- Vá para: https://supabase.com/dashboard
- Selecione seu projeto

#### 2. **Vá para Storage**
- Clique em **"Storage"** no menu lateral
- Clique na aba **"Policies"**

#### 3. **Criar Políticas para `avatars`**

**Política 1 - Upload:**
- Clique **"New Policy"**
- **Policy Name:** `Allow avatar uploads`
- **Allowed operation:** `INSERT`
- **Target roles:** `authenticated`
- **Policy definition:**
```sql
bucket_id = 'avatars'
```

**Política 2 - Visualização:**
- Clique **"New Policy"**  
- **Policy Name:** `Public avatar access`
- **Allowed operation:** `SELECT`
- **Target roles:** `public`
- **Policy definition:**
```sql
bucket_id = 'avatars'
```

**Política 3 - Atualização:**
- Clique **"New Policy"**
- **Policy Name:** `Allow avatar updates`
- **Allowed operation:** `UPDATE`
- **Target roles:** `authenticated`
- **Policy definition:**
```sql
bucket_id = 'avatars'
```

**Política 4 - Exclusão:**
- Clique **"New Policy"**
- **Policy Name:** `Allow avatar deletes`
- **Allowed operation:** `DELETE`
- **Target roles:** `authenticated`
- **Policy definition:**
```sql
bucket_id = 'avatars'
```

#### 4. **Criar Políticas para `backgrounds`**

Repita os mesmos 4 passos acima, mas trocando:
- `avatars` por `backgrounds`
- `avatar` por `background` nos nomes das políticas

#### 5. **Testar**
- Volte na aplicação
- Tente fazer upload de uma foto
- Se não der erro = ✅ **FUNCIONOU!**

---

## 🛠️ **MÉTODO ALTERNATIVO (SQL Editor):**

Se preferir usar SQL:

1. **SQL Editor** → Cole e execute:

```sql
-- Avatars
CREATE POLICY "Allow avatar uploads" ON storage.objects
FOR INSERT TO authenticated WITH CHECK (bucket_id = 'avatars');

CREATE POLICY "Public avatar access" ON storage.objects
FOR SELECT TO public USING (bucket_id = 'avatars');

CREATE POLICY "Allow avatar updates" ON storage.objects
FOR UPDATE TO authenticated USING (bucket_id = 'avatars');

CREATE POLICY "Allow avatar deletes" ON storage.objects
FOR DELETE TO authenticated USING (bucket_id = 'avatars');

-- Backgrounds
CREATE POLICY "Allow background uploads" ON storage.objects
FOR INSERT TO authenticated WITH CHECK (bucket_id = 'backgrounds');

CREATE POLICY "Public background access" ON storage.objects
FOR SELECT TO public USING (bucket_id = 'backgrounds');

CREATE POLICY "Allow background updates" ON storage.objects
FOR UPDATE TO authenticated USING (bucket_id = 'backgrounds');

CREATE POLICY "Allow background deletes" ON storage.objects
FOR DELETE TO authenticated USING (bucket_id = 'backgrounds');
```

---

## ✅ **VERIFICAR SE FUNCIONOU:**

1. Dashboard → Editar card → Upload foto
2. **SE:** Upload funciona sem erro = ✅ **RESOLVIDO!**
3. **SE:** Ainda dá erro = Verifique se os buckets foram criados como **públicos**

---

## 📋 **CHECKLIST COMPLETO:**

- [ ] Buckets `avatars` e `backgrounds` criados como **públicos**
- [ ] 4 políticas para `avatars` (INSERT, SELECT, UPDATE, DELETE)
- [ ] 4 políticas para `backgrounds` (INSERT, SELECT, UPDATE, DELETE)
- [ ] Teste de upload realizado sem erro

**DEPOIS DISSO, O UPLOAD VAI FUNCIONAR! 🚀**