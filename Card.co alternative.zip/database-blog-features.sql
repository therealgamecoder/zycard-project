-- ===============================================
-- NOVAS FUNCIONALIDADES - Blog e Customização de Fundo
-- Execute este SQL após os outros arquivos SQL
-- ===============================================

-- Adicionar campos de customização de fundo na tabela visual_cards
ALTER TABLE public.visual_cards 
ADD COLUMN IF NOT EXISTS background_color TEXT DEFAULT '#3b82f6',
ADD COLUMN IF NOT EXISTS background_gradient TEXT,
ADD COLUMN IF NOT EXISTS custom_css TEXT;

-- Verificar e criar colunas essenciais que podem estar faltando
DO $$ 
BEGIN
    -- Verificar e criar coluna slug
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name='visual_cards' AND column_name='slug') THEN
        ALTER TABLE public.visual_cards ADD COLUMN slug TEXT;
        
        -- Gerar slugs únicos para cards existentes sem slug
        UPDATE public.visual_cards 
        SET slug = LOWER(REGEXP_REPLACE(name, '[^a-zA-Z0-9]+', '-', 'g')) || '-' || SUBSTRING(id::text, 1, 8)
        WHERE slug IS NULL OR slug = '';
        
        -- Tornar a coluna NOT NULL e UNIQUE após popular
        ALTER TABLE public.visual_cards ALTER COLUMN slug SET NOT NULL;
        CREATE UNIQUE INDEX IF NOT EXISTS visual_cards_slug_key ON public.visual_cards(slug);
    END IF;
    
    -- Verificar e criar coluna country
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name='visual_cards' AND column_name='country') THEN
        ALTER TABLE public.visual_cards ADD COLUMN country TEXT;
    END IF;
    
    -- Verificar e criar coluna background_image_url
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name='visual_cards' AND column_name='background_image_url') THEN
        ALTER TABLE public.visual_cards ADD COLUMN background_image_url TEXT;
    END IF;
END $$;

-- Criar tabela de posts do blog
CREATE TABLE IF NOT EXISTS public.blog_posts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    card_id UUID REFERENCES public.visual_cards(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    excerpt TEXT,
    featured_image_url TEXT,
    slug TEXT NOT NULL,
    is_published BOOLEAN DEFAULT false NOT NULL,
    published_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    UNIQUE(card_id, slug)
);

-- Criar tabela de categorias do blog
CREATE TABLE IF NOT EXISTS public.blog_categories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    card_id UUID REFERENCES public.visual_cards(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    slug TEXT NOT NULL,
    color TEXT DEFAULT '#3b82f6',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    UNIQUE(card_id, slug)
);

-- Criar tabela de relacionamento post-categoria
CREATE TABLE IF NOT EXISTS public.blog_post_categories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    post_id UUID REFERENCES public.blog_posts(id) ON DELETE CASCADE NOT NULL,
    category_id UUID REFERENCES public.blog_categories(id) ON DELETE CASCADE NOT NULL,
    UNIQUE(post_id, category_id)
);

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_blog_posts_card_id ON public.blog_posts(card_id);
CREATE INDEX IF NOT EXISTS idx_blog_posts_slug ON public.blog_posts(card_id, slug);
CREATE INDEX IF NOT EXISTS idx_blog_posts_published ON public.blog_posts(is_published, published_at);
CREATE INDEX IF NOT EXISTS idx_blog_categories_card_id ON public.blog_categories(card_id);
CREATE INDEX IF NOT EXISTS idx_blog_post_categories_post_id ON public.blog_post_categories(post_id);

-- Enable RLS
ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blog_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blog_post_categories ENABLE ROW LEVEL SECURITY;

-- Políticas para blog_posts
CREATE POLICY "Users can manage posts of own cards" ON public.blog_posts
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND user_id = auth.uid()
        )
    );

CREATE POLICY "Anyone can view published posts of active cards" ON public.blog_posts
    FOR SELECT USING (
        is_published = true AND EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND is_active = true
        )
    );

-- Políticas para blog_categories
CREATE POLICY "Users can manage categories of own cards" ON public.blog_categories
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND user_id = auth.uid()
        )
    );

CREATE POLICY "Anyone can view categories of active cards" ON public.blog_categories
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.visual_cards 
            WHERE id = card_id AND is_active = true
        )
    );

-- Políticas para blog_post_categories
CREATE POLICY "Users can manage post categories of own cards" ON public.blog_post_categories
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.blog_posts bp
            JOIN public.visual_cards vc ON bp.card_id = vc.id
            WHERE bp.id = post_id AND vc.user_id = auth.uid()
        )
    );

CREATE POLICY "Anyone can view post categories of published posts" ON public.blog_post_categories
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.blog_posts bp
            JOIN public.visual_cards vc ON bp.card_id = vc.id
            WHERE bp.id = post_id AND bp.is_published = true AND vc.is_active = true
        )
    );

-- Função para atualizar timestamp
CREATE TRIGGER update_blog_posts_updated_at BEFORE UPDATE ON public.blog_posts
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Grant permissions
GRANT ALL ON public.blog_posts TO anon, authenticated;
GRANT ALL ON public.blog_categories TO anon, authenticated;
GRANT ALL ON public.blog_post_categories TO anon, authenticated;

-- ===============================================
-- STORAGE BUCKET PARA IMAGENS DO BLOG
-- ===============================================

-- Criar bucket 'blog-images' (execute no SQL Editor ou crie manualmente)
-- INSERT INTO storage.buckets (id, name, public) VALUES ('blog-images', 'blog-images', true);

-- Políticas de Storage para blog-images
-- (Execute no Storage > Policies)

-- CREATE POLICY "Allow authenticated users to upload blog images" ON storage.objects
-- FOR INSERT TO authenticated
-- WITH CHECK (bucket_id = 'blog-images');

-- CREATE POLICY "Allow public access to blog images" ON storage.objects
-- FOR SELECT TO public
-- USING (bucket_id = 'blog-images');

-- CREATE POLICY "Allow users to update their blog images" ON storage.objects
-- FOR UPDATE TO authenticated
-- USING (bucket_id = 'blog-images');

-- CREATE POLICY "Allow users to delete their blog images" ON storage.objects
-- FOR DELETE TO authenticated
-- USING (bucket_id = 'blog-images');

-- ===============================================
-- DADOS DE EXEMPLO PARA CORES DE FUNDO
-- ===============================================

/*
CORES E GRADIENTES PREDEFINIDOS:

Cores sólidas:
- #3b82f6 (Azul)
- #8b5cf6 (Roxo) 
- #10b981 (Verde)
- #f59e0b (Amarelo)
- #ef4444 (Vermelho)
- #06b6d4 (Ciano)
- #84cc16 (Lima)
- #f97316 (Laranja)

Gradientes:
- linear-gradient(135deg, #667eea 0%, #764ba2 100%)
- linear-gradient(135deg, #f093fb 0%, #f5576c 100%)
- linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)
- linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)
- linear-gradient(135deg, #fa709a 0%, #fee140 100%)
- linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)
- linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)
- linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)

TAMANHOS RECOMENDADOS PARA IMAGENS DE FUNDO:
- Desktop: 1920x1080px (16:9)
- Mobile: 1080x1920px (9:16)
- Quadrado: 1080x1080px (1:1)
- Banner: 1920x600px (16:5)
*/

-- ===============================================
-- COMENTÁRIOS DE USO
-- ===============================================

/*
COMO USAR AS NOVAS FUNCIONALIDADES:

1. CUSTOMIZAÇÃO DE FUNDO:
   - background_color: Cor sólida (hex)
   - background_gradient: CSS gradient
   - background_image_url: URL da imagem (já existia)
   - custom_css: CSS personalizado adicional

2. BLOG:
   - Cada card pode ter múltiplos posts
   - Posts podem ter categorias
   - Slug único por card
   - Sistema de publicação
   - Imagem destacada opcional

3. EXEMPLO DE USO:
   UPDATE visual_cards SET 
     background_color = '#8b5cf6',
     background_gradient = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
   WHERE id = 'card_id_here';

4. BLOG POST EXEMPLO:
   INSERT INTO blog_posts (card_id, title, content, excerpt, slug, is_published, published_at)
   VALUES (
     'card_id_here',
     'Meu primeiro post',
     'Conteúdo completo do post...',
     'Resumo do post',
     'meu-primeiro-post',
     true,
     NOW()
   );
*/