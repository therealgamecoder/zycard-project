# 📝 CONFIGURAÇÃO STORAGE PARA BLOG

## 🚨 **AÇÃO NECESSÁRIA - CRIAR BUCKET BLOG**

### **1. CRIAR BUCKET `blog-images`**

**No painel do Supabase:**
1. Vá em **Storage**
2. Clique **"New bucket"**
3. **Nome:** `blog-images`
4. **✅ Marque "Public bucket"**
5. Clique **"Create bucket"**

### **2. CONFIGURAR POLÍTICAS RLS**

**Vá em Storage → Policies e crie:**

#### **Política 1 - Upload (INSERT):**
- **Policy Name:** `Allow blog image uploads`
- **Allowed operation:** `INSERT`
- **Target roles:** `authenticated`
- **Policy definition:**
```sql
bucket_id = 'blog-images'
```

#### **Política 2 - Visualização (SELECT):**
- **Policy Name:** `Public blog image access`
- **Allowed operation:** `SELECT`
- **Target roles:** `public`
- **Policy definition:**
```sql
bucket_id = 'blog-images'
```

#### **Política 3 - Atualização (UPDATE):**
- **Policy Name:** `Allow blog image updates`
- **Allowed operation:** `UPDATE`
- **Target roles:** `authenticated`
- **Policy definition:**
```sql
bucket_id = 'blog-images'
```

#### **Política 4 - Exclusão (DELETE):**
- **Policy Name:** `Allow blog image deletes`
- **Allowed operation:** `DELETE`
- **Target roles:** `authenticated`
- **Policy definition:**
```sql
bucket_id = 'blog-images'
```

---

## 🎯 **RESULTADO ESPERADO:**

Após configurar, você terá:
- ✅ Bucket `blog-images` público
- ✅ 4 políticas RLS configuradas
- ✅ Upload de imagens funcionando no blog

---

## 🧪 **COMO TESTAR:**

1. **Dashboard** → Card → **"Gerenciar Blog"**
2. **"Novo Post"** → Upload de imagem destacada
3. **SE:** Upload funciona = ✅ **CONFIGURADO!**
4. **SE:** Erro "Bucket not found" = ❌ Criar bucket
5. **SE:** Erro "violates row-level security" = ❌ Configurar políticas

---

## 📋 **CHECKLIST COMPLETO:**

- [ ] Bucket `blog-images` criado como **público**
- [ ] Política INSERT configurada
- [ ] Política SELECT configurada  
- [ ] Política UPDATE configurada
- [ ] Política DELETE configurada
- [ ] Teste de upload realizado com sucesso

**DEPOIS DISSO, O BLOG ESTARÁ 100% FUNCIONAL! 🚀**